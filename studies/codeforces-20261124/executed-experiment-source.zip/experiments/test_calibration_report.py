"""Financial and data-separation checks for the Markdown report generator."""

from pathlib import Path
import tempfile
import unittest

from experiments.analysis import analyze
from experiments.calibration_report import build_report, main, _success
from experiments.test_analysis import result, planned
from experiments.three_arm_analysis import analyze_three_arms


class CalibrationReportTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        rows = []
        for task in range(10):
            for repetition in range(2):
                for condition, cost in (("baseline", .001), ("verifier", .002), ("guided_verifier", .003)):
                    rows.append(result(str(task), condition, task % 3 != 0, repetition,
                                       model_cost_usd=cost, band="2000-2399" if task < 5 else "2400+"))
        cls.optional = [row for row in rows if row["condition"] != "guided_verifier"]
        cls.guided = [row for row in rows if row["condition"] == "guided_verifier"]
        cls.combined = analyze_three_arms(rows, planned(rows), phase="calibration", bootstrap_draws=100)
        cls.optional_summary = analyze(cls.optional, planned(cls.optional), bootstrap_draws=100)
        cls.guided_summary = analyze(cls.guided, planned(cls.guided), bootstrap_draws=100)
        cls.screen_rows = [dict(row, repetition=repetition) for row in rows if row["condition"] == "baseline" and row["repetition"] == 0 and int(row["task_id"]) in (0, 1, 5, 6)
                           for repetition in (0, 1)]
        cls.screen = analyze(cls.screen_rows, planned(cls.screen_rows), phase="model_screen", bootstrap_draws=100)
        cls.config = {"max_output_tokens": 16384, "effort": "medium", "step_limit": 12, "solve_limit_seconds": 600}
        cls.manifest = {"tasks": [{"id": f"main-{i}", "family": f"main-{i}", "rating_band": "2000-2399" if i < 50 else "2400+",
                                   "private_test_count": 22 if i < 60 else 23} for i in range(100)],
                        "reserves": [], "calibration_tasks": [{"id": str(i), "family": str(i), "private_test_count": 10} for i in range(10)],
                        "reference_preflight_summary": {"attempted": 141, "passed": 139}}
        cls.ledger = {"reservations": {"settled": {"status": "settled", "charged": "2"},
                                       "uncertain": {"status": "usage_upper_bound", "charged": ".5"},
                                       "pending": {"status": "pending", "reserved": ".25"}}}

    def report(self, *, combined=True, guided=True, **extra):
        return build_report(self.screen, self.optional_summary, self.manifest, self.ledger,
                            screen_expected={"runs": planned(self.screen_rows), "config": self.config},
                            calibration_expected={"runs": planned(self.optional), "config": self.config},
                            guided=self.guided_summary if guided else None,
                            guided_expected={"runs": planned(self.guided), "config": self.config},
                            three_arm_summary=self.combined if combined else None, **extra)

    def test_three_arm_forecasts_count_shared_baseline_once_and_caps_fit(self):
        text = self.report()
        self.assertIn("900 runs", text)
        self.assertIn("$108.00", text)
        self.assertIn("$114.00", text)
        self.assertIn("$0.1277", text)
        self.assertIn("$1.80", text)
        self.assertIn("2,240", text)
        self.assertIn("97.5% interval per contrast", text)
        self.assertIn("guided minus baseline **0.0 pp**", text)
        self.assertIn("$2.7500", text)
        self.assertIn("**18.75 hours at c8**", text)

    def test_split_summaries_work_but_missing_guided_blocks_estimates(self):
        text = self.report(combined=False)
        self.assertIn("Three-arm calibration completion: **complete**", text)
        missing = self.report(combined=False, guided=False)
        self.assertIn("conditional/unavailable", missing)
        self.assertNotIn("$1.80", missing)

    def test_new_configs_do_not_assume_different_output_caps(self):
        text = self.report()
        self.assertEqual(text.count("16,384"), 3)
        self.assertNotIn("larger output cap", text)
        self.assertIn("Their charges remain included", text)

    def test_non95_descriptive_bounds_are_not_labelled95(self):
        cell = _success({"success_interval": {"estimate_percent": 50, "confidence_level": .975,
                                             "confidence_interval_percent": [10, 90], "ci95_percent": None}}, True)
        self.assertIn("97.5%", cell)
        self.assertNotIn("95.0%", cell)

    def test_default_cli_never_opens_excluded_debug_analysis(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "model-screen").mkdir()
            (root / "model-screen/analysis.json").write_text("invalid excluded debug JSON", encoding="utf-8")
            (root / "model-screen-v2").mkdir()
            (root / "model-screen-v2/analysis.json").write_text("invalid excluded v2 JSON", encoding="utf-8")
            (root / "three-arm-analysis.json").write_text("invalid excluded v2 combined JSON", encoding="utf-8")
            output = root / "report.md"
            self.assertEqual(main(["--root", str(root), "--output", str(output)]), 0)
            self.assertIn("guided-calibration-v3", output.read_text(encoding="utf-8"))

    def test_source_quality_limits_are_read_from_the_audit(self):
        quality = {"main_coverage": {"tasks": 100, "median_task_max_private_input_chars": 114.5,
                                    "max_private_input_chars": 503, "tasks_max_private_input_below_100_chars": 44},
                   "probe_domain_checks": {"cf-probe": {"generated": {"invalid_case_count": 46, "case_count": 53}}}}
        text = self.report(source_quality=quality, source_quality_md_available=True)
        self.assertIn("114.5 characters", text)
        self.assertIn("44/100", text)
        self.assertIn("46/53", text)
        self.assertIn("CI does not cover missing-test uncertainty", text)
        self.assertIn("[source-quality.md](source-quality.md)", text)

    def test_tool_audit_excludes_all_old_batches_and_marks_missing_coverage(self):
        audit = {"runs": [{"batch": "paired-calibration-v2", "model": "test-model", "condition": "verifier",
                           "verifier_usage_observed": True, "observed_wrapper_start_count": 99,
                           "diagnostic_call_counts": {"old_invalid_diagnostic": 99}},
                          {"batch": "paired-calibration-v3", "model": "test-model", "condition": "verifier",
                           "verifier_usage_observed": True, "observed_wrapper_start_count": 2,
                           "diagnostic_call_counts": {"counterexample": 1}, "source_changed_after_any_verifier_action": True}]}
        text = self.report(process_audit=audit)
        self.assertIn("counterexample=1", text)
        self.assertNotIn("old_invalid_diagnostic", text)
        self.assertIn("selected calibration batches (partial)", text)
        self.assertIn("| verifier | 1/20 | 1 | 2 |", text)

    def test_old_only_process_audit_is_unavailable_not_zero_tool_use(self):
        text = self.report(process_audit={"runs": [{"batch": "paired-calibration-v2", "model": "test-model"}]})
        self.assertIn("Tool-use process audit for the selected replacement calibration batches: **unavailable**", text)

    def test_domain_audit_does_not_become_a_legal_bug_repair_claim(self):
        text = self.report(domain_audit={"task": "cf-1384-E", "repetition": 2,
                           "is_legal_task_counterexample": False, "reason": "NUL and ^ lie outside a..t.",
                           "executable_ast_unchanged_after_removing_docstrings": True, "hidden_passed": False},
                           trace_notes_available=True)
        self.assertIn("outside the task's legal input domain", text)
        self.assertIn("executable AST was unchanged", text)
        self.assertIn("final submission still failed", text)
        self.assertIn("not demonstrated legal-input algorithm repair", text)
        self.assertIn("ephemeral `/tmp`", text)

    def test_cap_replay_is_descriptive_and_counts_are_not_hard_coded(self):
        text = self.report(cap_replay={"proposed_cap_usd": ".12", "models": {"test-model": {
                           "completed_runs": 64, "recorded_runs_fitting_proposed_cap": 64,
                           "max_required_cap_usd": ".0576"}}}, cap_replay_source="cap-replay.partial.json")
        self.assertIn("**64/64**", text)
        self.assertIn("$0.057600", text)
        self.assertIn("not a guarantee for unseen main tasks", text)

    def test_retry_policy_describes_one_bounded_retry(self):
        text = self.report()
        self.assertIn("one deadline-aware transient request retry", text)
        self.assertIn("max_retries=1", text)
        self.assertNotIn("disables implicit API retries", text)

    def test_exploratory_paired_bounds_display_actual_coverage_and_no_main_claim(self):
        exploratory = {"confidence_level": .975, "models": {"test-model": {
            "family_count": 10, "difference_percentage_points": {"estimate": 5,
            "confidence_level": .975, "confidence_interval": [-20, 30],
            "conservative_confidence_interval": None}}}}
        combined = {**self.combined, "exploratory_contrasts": {"optional_vs_baseline": exploratory, "guided_vs_baseline": exploratory}}
        text = build_report(None, None, None, None, three_arm_summary=combined,
                            calibration_expected={"runs": planned(self.optional), "config": self.config},
                            guided_expected={"runs": planned(self.guided), "config": self.config})
        self.assertIn("exploratory paired development intervals", text)
        self.assertIn("[-20.0, 30.0] 97.5% B", text)
        self.assertIn("development outcomes were already inspected", text)
        self.assertIn("no main effectiveness result", text)


if __name__ == "__main__":
    unittest.main()
