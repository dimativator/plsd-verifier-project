The extension controller runs the same frozen benchmark in successive batches of
300 evaluations: 100 tasks and three conditions, starting at global repetition 6.
It waits for our current repetitions 1–3 to finish, and leaves the colleague's
repetitions 4–5 alone. Model, prompts, task data, Docker images and per-run limits
are checked against the original frozen protocol.

One ledger covers every extension batch. The default **$50 cap applies to new
batches on this controller**, summed across all conditions and repetitions.
Existing experiments and the colleague's independently running ledger are outside
that default cap. A shared API key does not share local accounting. To include
other spending, first obtain final ledgers or enforce separate remaining
allocations, then explicitly deduct those amounts using `--prior-charge-usd` and
`--remote-reserve-usd`; their sum plus this controller's ledger cannot exceed the
chosen combined cap. Do not treat a live remote cost snapshot as a final charge.

The controller holds each active run's entire remaining $0.12 allowance before
launching another run. Pending requests and uncertain charges count toward the
cap. It stops admissions when another run cannot fit, when `STOP` exists, or when
an infrastructure error needs inspection. Active evaluations finish normally.
The last batch can be partial; its results are preserved, its unstarted jobs are
missing, and the partial repetition is excluded from repetition averages and
sample variance. Continuation never depends on measured scores. Retain the
original five-round analysis separately from this budget-limited extension.

From the repository folder in PowerShell, prepare without loading a key:

```powershell
.\.venv\Scripts\python.exe -m experiments.extend_rounds run --plan runs/split-rounds-main-20261123-v4/protocol/plan.json --manifest runs/calibration-20261123/validated-task-manifest.json --after-worker runs/split-rounds-main-20261123-v4/ours/main-ours-v4 --output runs/extension-50usd-20261124 --cap-usd 50.00 --workers 8 --prepare-only
```

Run the same command without `--prepare-only` to execute. The key is loaded
locally only after the predecessor finishes and a run is admitted. For detached
execution, use the generated `START_EXTENSION.ps1` in the output folder.

Inspect or stop the extension:

```powershell
.\.venv\Scripts\python.exe -m experiments.extend_rounds status --output runs/extension-50usd-20261124
.\.venv\Scripts\python.exe -m experiments.extend_rounds stop --output runs/extension-50usd-20261124
```

Outputs include `status.json`, `spend/ledger.json`, and an `expected.json` and
`batch-report.json` inside each `extension-rep-XXXX` folder. Completed attempts
are skipped on resume. An incomplete attempt directory requires inspection;
never delete it to rerun an answer. Keep using the same output folder so that a
restart shares the same budget and cannot create duplicate repetition IDs.
