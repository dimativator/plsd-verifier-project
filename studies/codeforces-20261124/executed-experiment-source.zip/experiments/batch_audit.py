"""Reconcile completed batch identities and observed artifact timing."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path


def audit(root: Path) -> dict:
    expected_path = root / 'expected.json'
    expected = json.loads(expected_path.read_text(encoding='utf-8'))
    paths = list(root.glob('*/*/*/*/result.json'))
    rows = [json.loads(p.read_text(encoding='utf-8')) for p in paths]
    key = lambda row: tuple(row[k] for k in ['model', 'task_id', 'condition', 'repetition'])
    planned, observed = {key(r) for r in expected['runs']}, Counter(key(r) for r in rows)
    complete = (set(observed) == planned and all(n == 1 for n in observed.values())
                and all(r['valid_run'] and not r['infrastructure_error'] for r in rows))
    started = expected_path.stat().st_mtime
    finished = max((p.stat().st_mtime for p in paths), default=started)
    total = sum(r['solve_seconds'] + r['evaluation_seconds'] for r in rows)
    calls = []
    for path in root.glob('*/*/*/*/model/call-*/completion.json'):
        value = json.loads(path.read_text(encoding='utf-8'))
        calls.append(value)
    response_ids = Counter(c['response_id'] for c in calls)
    usage_totals = Counter()
    for call in calls:
        usage = call['usage']
        for field in ('input_tokens', 'output_tokens', 'total_tokens'):
            usage_totals[field] += usage.get(field, 0)
        details = usage.get('input_tokens_details') or {}
        usage_totals['cached_input_tokens'] += details.get('cached_tokens', 0)
        usage_totals['cache_write_tokens'] += details.get('cache_write_tokens', 0)
        usage_totals['cache_write_12h_tokens'] += (details.get('cache_write_tokens_details') or {}).get('ttl_12h_tokens', 0)
        usage_totals['reasoning_output_tokens'] += (usage.get('output_tokens_details') or {}).get('reasoning_tokens', 0)
    return {'complete': complete, 'planned_runs': len(planned), 'completed_runs': len(rows),
        'invalid_runs': sum(not r['valid_run'] or bool(r['infrastructure_error']) for r in rows),
        'started_utc_from_manifest_mtime': datetime.fromtimestamp(started, timezone.utc).isoformat(),
        'finished_utc_from_last_result_mtime': datetime.fromtimestamp(finished, timezone.utc).isoformat() if complete else None,
        'observed_batch_seconds': finished - started if complete else None,
        'serial_solve_plus_evaluation_seconds': total,
        'completed_api_calls': len(calls),
        'general_final_text_selection_warnings': sum(bool(c.get('selection_error')) for c in calls),
        'unique_response_ids': len(response_ids),
        'duplicate_response_ids': [identity for identity, n in response_ids.items() if n > 1],
        'usage_totals': dict(usage_totals),
        'api_incomplete_responses': sum(c['status'] != 'completed' for c in calls),
        'resolved_model_ids': dict(Counter(c['resolved_model'] for c in calls)),
        'usage_cost_kinds': dict(Counter(c['cost_kind'] for c in calls)),
        'note': 'Batch timing reconstructed from immutable artifact timestamps. The three preparation v3 batches each used four workers concurrently; main throughput may differ.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results', type=Path, required=True)
    args = parser.parse_args()
    result = audit(args.results)
    path = args.results / 'batch-audit.json'
    path.write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
