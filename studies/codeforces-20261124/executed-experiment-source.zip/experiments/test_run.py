"""The last saved implementation must be scored after a resource-limit exit."""
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

os.environ['MSWEA_SILENT_STARTUP'] = '1'

from experiments.api_backend import BudgetExceeded, Completion, SpendLedger
from experiments import run


class SchedulingTests(unittest.TestCase):
    def test_three_arm_blocks_cover_every_order_and_position(self):
        from collections import Counter
        arms = ['baseline', 'verifier', 'guided_verifier']
        orders = [run.condition_order(arms, i) for i in range(300)]
        self.assertEqual(len(set(orders)), 6)
        self.assertEqual(set(Counter(orders).values()), {50})
        for position in range(3):
            self.assertEqual(set(Counter(order[position] for order in orders).values()), {100})

    def test_six_repetitions_cover_every_order_for_each_task_and_band(self):
        from collections import Counter
        arms = ['baseline', 'verifier', 'guided_verifier']
        for band in ('2000', '2400'):
            observed = []
            for index in range(50):
                orders = [run.task_condition_order(arms, f'{band}-{index}', repetition)
                          for repetition in range(1, 7)]
                self.assertEqual(len(set(orders)), 6)
                observed.extend(orders)
            self.assertEqual(set(Counter(observed).values()), {50})

    def test_task_orders_do_not_depend_on_shard_size_or_position(self):
        arms = ['baseline', 'verifier', 'guided_verifier']
        tasks = [f'task-{index}' for index in range(100)]
        global_orders = {(task, rep): run.task_condition_order(arms, task, rep)
                         for task in tasks for rep in range(1, 7)}
        shard_orders = {(task, rep): run.task_condition_order(arms, task, rep)
                        for shard in (tasks[::2], tasks[1::2])
                        for task in reversed(shard) for rep in range(1, 7)}
        self.assertEqual(global_orders, shard_orders)

    def test_invalid_repetition_cannot_create_a_second_identity(self):
        for repetition in (0, -1, True, 1.5):
            with self.subTest(repetition=repetition), self.assertRaises(ValueError):
                run.task_condition_order(['baseline'], 'task', repetition)


class LastArtifactTests(unittest.TestCase):
    def test_budget_exhaustion_scores_final_source_and_keeps_denominator(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            public = root / 'benchmark-data/codecontests/tasks/task/public'
            hidden = public.parent / 'evaluator'
            public.mkdir(parents=True)
            hidden.mkdir()
            (public / 'prompt.txt').write_text('Double an integer.')
            (public / 'public-tests.json').write_text(json.dumps({'input': ['2'], 'output': ['4']}))
            (hidden / 'private-tests.json').write_text(json.dumps({'input': ['3'], 'output': ['6']}))
            ledger = SpendLedger(root / 'spend')

            class Backend:
                def __init__(self, **kwargs):
                    self.__dict__.update(kwargs)
                    self.calls = 0

                def complete(self, messages, *, run_id):
                    self.calls += 1
                    if self.calls > 1:
                        raise BudgetExceeded('Run cap reached')
                    identity = ledger.reserve(run_id, '.01')
                    ledger.settle(identity, '.01')
                    return Completion('```mswea_bash_command\nwrite_solution\n```',
                        self.model, self.model, 'response-test', {'input_tokens': 1, 'output_tokens': 1},
                        '.01', .1, 'completed', None, 'test', 'default', 'usage_derived')

            def execute(workspace, command, **kwargs):
                self.assertEqual(command, 'write_solution')
                (workspace / 'main.py').write_text('print(int(input()) * 2)\n')
                return {'returncode': 0, 'stdout': '', 'stderr': '', 'timed_out': False,
                        'elapsed_seconds': .1, 'output_truncated': False}

            def evaluate(source, tests, scratch, checker):
                self.assertIn('* 2', source.read_text())
                return {'passed': True, 'test_count': 1, 'stage': 'hidden_tests'}

            config = {'output': str(root / 'batch'), 'max_output_tokens': 100,
                      'effort': 'medium', 'step_limit': 12, 'solve_limit_seconds': 30}
            spec = {'phase': 'calibration', 'model': 'gpt-6-luna', 'task_id': 'task',
                    'family_id': 'task', 'rating_band': '2000-2399', 'condition': 'baseline', 'repetition': 1}
            with patch.object(run, 'PROJECT', root), patch.object(run, 'OpenAIResponsesBackend', Backend), \
                    patch.object(run, 'run_isolated', execute), patch.object(run, 'evaluate_python', evaluate):
                result = run.execute({'id': 'task', 'checker': 'integer_tokens'}, spec, config, ledger, 'DUMMY')
            self.assertTrue(result['valid_run'])
            self.assertTrue(result['hidden_passed'])
            self.assertIsNone(result['infrastructure_error'])
            self.assertEqual(result['exit_status'], 'budget_exhausted')
            self.assertEqual(result['model_cost_usd'], .01)


if __name__ == '__main__':
    unittest.main()
