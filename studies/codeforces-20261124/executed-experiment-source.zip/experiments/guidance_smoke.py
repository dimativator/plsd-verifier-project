"""CPU-only qualification of synthetic generic CrossHair teaching examples.

No benchmark tasks, tests, solver scaffolds or frozen controller files change.
Contracts below belong to toy examples only and are authored in source files;
the existing verifier wrapper does not inject a specification.
"""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import re
import time

from experiments.runtime import BASE_IMAGE, VERIFIER_IMAGE, run_isolated

PROJECT = Path(__file__).resolve().parents[1]

CRATES_BODY = '''def ceil_crates(items: int, capacity: int) -> int:
DOCSTRING    return EXPRESSION


if __name__ == '__main__':
    import sys
    print(ceil_crates(*map(int, sys.stdin.read().split())))
'''
CRATES_CONTRACT = '''    """
    pre: items >= 0
    pre: capacity > 0
    post: _ >= 0
    post: _ * capacity >= items
    post: _ == 0 or (_ - 1) * capacity < items
    """
'''
CRATES_REPLAY = '''import json,sys
from main import ceil_crates
items,capacity=json.load(sys.stdin)
legal=items>=0 and capacity>0
if not legal:raise ValueError('Illegal toy-example input')
actual=ceil_crates(items,capacity)
properties={'nonnegative':actual>=0,'covers_items':actual*capacity>=items,
            'minimal':actual==0 or (actual-1)*capacity<items}
print(json.dumps({'arguments':[items,capacity],'legal_input':legal,'actual':actual,
                  'properties':properties,'all_properties_passed':all(properties.values())}))
'''
CLAMP_MAIN = '''def clamp(value: int, lower: int, upper: int) -> int:
    return max(lower, min(value, UPPER_EXPRESSION))
'''
CLAMP_CONTRACT = '''from main import clamp


def ENTRYPOINT(value: int, lower: int, upper: int) -> int:
    """
    pre: lower <= upper
    post: lower <= _ <= upper
    post: _ == (lower if value < lower else upper if value > upper else value)
    """
    return clamp(value, lower, upper)
'''
CLAMP_REPLAY = '''import json,sys
from main import clamp
value,lower,upper=json.load(sys.stdin)
legal=lower<=upper
if not legal:raise ValueError('Illegal toy-example input')
actual=clamp(value,lower,upper)
expected=lower if value<lower else upper if value>upper else value
properties={'within_bounds':lower<=actual<=upper,'specified_value':actual==expected}
print(json.dumps({'arguments':[value,lower,upper],'legal_input':legal,'actual':actual,
                  'expected':expected,'properties':properties,'all_properties_passed':all(properties.values())}))
'''


def save(path: Path, payload: object) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def parse_case(function: str, names: tuple[str, ...], diagnostic: str) -> list[int] | None:
    for match in re.finditer(r'when calling ' + re.escape(function) + r'\(([^()\n]*)\)', diagnostic):
        try:
            call = ast.parse('f(' + match.group(1) + ')', mode='eval').body
            values = [ast.literal_eval(node) for node in call.args]
            named = {item.arg: ast.literal_eval(item.value) for item in call.keywords}
            for name in names[len(values):]:
                values.append(named.pop(name))
            if not named and len(values) == len(names) and all(type(value) is int for value in values):
                return values
        except (ValueError, KeyError, TypeError, SyntaxError):
            continue
    return None


def qualify(output: Path) -> dict:
    output.mkdir(parents=True, exist_ok=False)
    sources = {
        'crates_unannotated': {'main.py': CRATES_BODY.replace('DOCSTRING', '').replace('EXPRESSION', '(items + capacity - 1) // capacity')},
        'crates_correct': {'main.py': CRATES_BODY.replace('DOCSTRING', CRATES_CONTRACT).replace('EXPRESSION', '(items + capacity - 1) // capacity')},
        'crates_mutant': {'main.py': CRATES_BODY.replace('DOCSTRING', CRATES_CONTRACT).replace('EXPRESSION', 'items // capacity'), 'replay.py': CRATES_REPLAY},
        'sidecar_private': {'main.py': CLAMP_MAIN.replace('UPPER_EXPRESSION', 'upper'),
                            'check_contract.py': CLAMP_CONTRACT.replace('ENTRYPOINT', '_check_clamp')},
        'sidecar_correct': {'main.py': CLAMP_MAIN.replace('UPPER_EXPRESSION', 'upper'),
                            'check_contract.py': CLAMP_CONTRACT.replace('ENTRYPOINT', 'check_clamp')},
        'sidecar_mutant': {'main.py': CLAMP_MAIN.replace('UPPER_EXPRESSION', 'upper - 1'),
                           'check_contract.py': CLAMP_CONTRACT.replace('ENTRYPOINT', 'check_clamp'), 'replay.py': CLAMP_REPLAY},
    }
    for variant, files in sources.items():
        workspace = output / variant
        workspace.mkdir()
        for name, text in files.items():
            (workspace / name).write_text(text, encoding='utf-8')
    save(output / 'source-bundle.json', {
        'purpose': 'Synthetic generic teaching examples only; not derived from benchmark tasks.',
        'domains': {'ceil_crates': 'All integer items>=0, capacity>0.',
                    'clamp': 'All integer value,lower,upper with lower<=upper.'},
        'arbitrary_size_bounds': None, 'model_api_calls': 0, 'benchmark_inputs_or_references': False,
        'contracts_injected_by_wrapper': False,
        'source_sha256': {str(path.relative_to(output)): hashlib.sha256(path.read_bytes()).hexdigest()
                          for path in output.glob('*/*.py')},
        'limits': {'wrapper_seconds': 30, 'per_condition_seconds': 10, 'per_path_seconds': 5},
    })
    started = time.monotonic()
    checks = {}
    for variant in sources:
        target = 'check_contract.py' if variant.startswith('sidecar') else 'main.py'
        command = 'verify ' + target
        result = run_isolated(output / variant, command, image=VERIFIER_IMAGE, timeout=35)
        checks[variant] = {'command': command, **result}
        save(output / (variant + '.json'), checks[variant])
        print(json.dumps({'example': variant, 'returncode': result['returncode'],
                          'elapsed_seconds': result['elapsed_seconds'], 'stdout': result['stdout'],
                          'stderr': result['stderr']}), flush=True)
    replays = {}
    for variant, function, fields, fallback in (
            ('crates_mutant', 'ceil_crates', ('items', 'capacity'), [1, 2]),
            ('sidecar_mutant', 'check_clamp', ('value', 'lower', 'upper'), [2, 0, 2])):
        text = checks[variant]['stdout'] + '\n' + checks[variant]['stderr']
        case = parse_case(function, fields, text)
        origin = 'parsed_crosshair_counterexample' if case is not None else 'preselected_fixture_not_a_crosshair_replay'
        result = run_isolated(output / variant, 'python -B replay.py', image=BASE_IMAGE,
                              timeout=20, input_text=json.dumps(case if case is not None else fallback))
        record = {'case_source': origin, **result}
        if result['returncode'] == 0:
            record['ordinary_python'] = json.loads(result['stdout'])
        replays[variant] = record
        save(output / (variant + '-replay.json'), record)
    def diagnostic(name):
        return checks[name]['stdout'] + checks[name]['stderr']
    qualification = {
        'unannotated_reports_no_entrypoints': 'no checkable functions' in diagnostic('crates_unannotated'),
        'correct_crates_confirmed': 'Confirmed over all paths.' in diagnostic('crates_correct')
                                    and 'Not confirmed.' not in diagnostic('crates_correct'),
        'private_sidecar_is_supported_by_installed_version': 'Confirmed over all paths.' in diagnostic('sidecar_private')
                                    and 'Not confirmed.' not in diagnostic('sidecar_private'),
        'public_sidecar_confirmed': 'Confirmed over all paths.' in diagnostic('sidecar_correct')
                                    and 'Not confirmed.' not in diagnostic('sidecar_correct'),
        'crates_legal_counterexample_replayed': replays['crates_mutant']['case_source'] == 'parsed_crosshair_counterexample'
                  and replays['crates_mutant'].get('ordinary_python', {}).get('legal_input') is True
                  and replays['crates_mutant']['ordinary_python'].get('all_properties_passed') is False,
        'imported_actual_clamp_legal_counterexample_replayed': replays['sidecar_mutant']['case_source'] == 'parsed_crosshair_counterexample'
                  and replays['sidecar_mutant'].get('ordinary_python', {}).get('legal_input') is True
                  and replays['sidecar_mutant']['ordinary_python'].get('all_properties_passed') is False,
    }
    report = {'kind': 'CPU-only synthetic guidance qualification', 'qualification': qualification,
              'all_checks_passed': all(qualification.values()), 'checks': checks, 'replays': replays,
              'elapsed_seconds': time.monotonic() - started,
              'limitations': ['Synthetic deliberately seeded bugs are not evidence of agent or benchmark accuracy improvement.',
                              'Domains contain no arbitrary input-size bounds; confirmation is the installed tool report, not an independent mathematical proof.',
                              'Sidecar checks actual imported implementation; it contains no separate algorithm replacement.',
                              'Examples are generic guidance material only; no benchmark-specific scaffold or property is supplied.',
                              'A leading underscore does not hide the specified sidecar entrypoint in this installed version; naming alone is not the cause of empty checks.',
                              'CrossHair assertion mode treats leading assertions as assumptions; these examples deliberately use explicit PEP316 contracts.']}
    save(output / 'report.json', report)
    lines = ['# Synthetic guidance qualification', '',
             'No API calls, benchmark inputs, task-specific scaffolds, or frozen core edits.', '',
             'Both examples use their complete declared legal integer domain, without arbitrary size bounds.', '',
             '## Results', '', '```json', json.dumps(qualification, indent=2), '```', '']
    for name, result in checks.items():
        lines += [f'### {name}', '', f'`{result["command"]}` — {result["elapsed_seconds"]:.3f}s, return code {result["returncode"]}.',
                  '', '```text', result['stdout'] + result['stderr'], '```', '']
    lines += ['## Actual counterexample replay', '', '```json', json.dumps({name: row.get('ordinary_python', {}) for name, row in replays.items()}, indent=2), '```', '',
              '## Limits', '', *['- ' + item for item in report['limitations']]]
    (output / 'README.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(json.dumps({'output': str(output), 'qualification': qualification,
                      'all_checks_passed': report['all_checks_passed'], 'elapsed_seconds': report['elapsed_seconds']}), flush=True)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=PROJECT / 'runs/calibration-20261123/guidance-smoke')
    args = parser.parse_args()
    report = qualify(args.output.resolve())
    raise SystemExit(0 if report['all_checks_passed'] else 1)


if __name__ == '__main__':
    main()
