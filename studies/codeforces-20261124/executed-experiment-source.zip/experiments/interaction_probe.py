"""CPU-only, bounded CrossHair interaction demonstration on public CF483B.

This is an engineered diagnostic with a seeded bug, not an agent experiment or
an estimate of benchmark improvement. No API, hidden tests, or reference solution
is used. The complete candidate/specification/replay sources are saved first.
"""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import re
import shutil
import time

from experiments.runtime import BASE_IMAGE, VERIFIER_IMAGE, evaluate_python, run_isolated

PROJECT = Path(__file__).resolve().parents[1]

CANDIDATE = '''import sys


def minimum_v(cnt1: int, cnt2: int, x: int, y: int) -> int:
    lo, hi = 0, 2 * (cnt1 + cnt2)
    while lo < hi:
        mid = (lo + hi) // 2
        if (mid - mid // x >= cnt1
                and mid - mid // y >= cnt2
                and mid - mid // (x * y) >= cnt1 + cnt2):
            hi = mid
        else:
            lo = mid + 1
    return RETURN_BOUNDARY


if __name__ == '__main__':
    print(minimum_v(*map(int, sys.stdin.buffer.read().split())))
'''

CONTRACT = '''from candidate import minimum_v


def allocation_feasible(v: int, cnt1: int, cnt2: int, x: int, y: int) -> bool:
    # Each recipient needs enough admissible numbers. Their union excludes only
    # multiples of x*y because x,y are distinct primes. For two recipient sets,
    # these individual and combined capacity conditions characterize allocation.
    return (v >= 0 and v - v // x >= cnt1
            and v - v // y >= cnt2
            and v - v // (x * y) >= cnt1 + cnt2)


def checked_minimum(cnt1: int, cnt2: int, x: int, y: int) -> int:
    """
    pre: 1 <= cnt1 <= 3
    pre: 1 <= cnt2 <= 3
    pre: (x, y) in ((2, 3), (2, 5), (3, 5))
    post: allocation_feasible(_, cnt1, cnt2, x, y)
    post: not allocation_feasible(_ - 1, cnt1, cnt2, x, y)
    """
    return minimum_v(cnt1, cnt2, x, y)
'''

GRID = '''from itertools import combinations, product
import json
from candidate import minimum_v
from check_contract import allocation_feasible

PAIRS = ((2, 3), (2, 5), (3, 5))


def enumerated_feasible(v, cnt1, cnt2, x, y):
    # Independently enumerate the first recipient's sets. Any cnt2 remaining
    # numbers in the second recipient's admissible set complete an allocation.
    first = [n for n in range(1, v + 1) if n % x]
    second = {n for n in range(1, v + 1) if n % y}
    return any(len(second - set(given)) >= cnt2
               for given in combinations(first, cnt1))


def inspect_case(cnt1, cnt2, x, y):
    legal = (1 <= cnt1 <= 3 and 1 <= cnt2 <= 3 and (x, y) in PAIRS)
    if not legal:
        raise ValueError('Replay must stay in the declared legal bounded domain')
    expected = next(v for v in range(2 * (cnt1 + cnt2) + 1)
                    if enumerated_feasible(v, cnt1, cnt2, x, y))
    actual = minimum_v(cnt1, cnt2, x, y)
    feasible = allocation_feasible(actual, cnt1, cnt2, x, y)
    minimal = not allocation_feasible(actual - 1, cnt1, cnt2, x, y)
    return {'arguments': [cnt1, cnt2, x, y], 'legal_bounded_input': legal,
            'candidate_v': actual, 'enumeration_oracle_v': expected,
            'feasible_at_v': feasible, 'not_feasible_at_v_minus_one': minimal,
            'functional_property_passed': feasible and minimal,
            'candidate_matches_enumeration': actual == expected}


def main():
    formula_checks, cases = 0, []
    for cnt1, cnt2 in product(range(1, 4), repeat=2):
        for x, y in PAIRS:
            for v in range(13):
                assert allocation_feasible(v, cnt1, cnt2, x, y) == enumerated_feasible(v, cnt1, cnt2, x, y)
                formula_checks += 1
            cases.append(inspect_case(cnt1, cnt2, x, y))
    print(json.dumps({'legal_cases': len(cases), 'independent_feasibility_formula_checks': formula_checks,
                      'candidate_matches': sum(row['candidate_matches_enumeration'] for row in cases),
                      'property_failures': [row for row in cases if not row['functional_property_passed']]}))


if __name__ == '__main__':
    main()
'''

REPLAY = '''import json,sys
from grid_validate import inspect_case
print(json.dumps(inspect_case(*json.load(sys.stdin))))
'''


def save(path: Path, payload: object) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def parsed_counterexample(text: str) -> list[int] | None:
    for match in re.finditer(r'when calling checked_minimum\(([^()\n]*)\)', text):
        try:
            call = ast.parse('f(' + match.group(1) + ')', mode='eval').body
            values = [ast.literal_eval(node) for node in call.args]
            if call.keywords:
                mapped = {key.arg: ast.literal_eval(key.value) for key in call.keywords}
                for name in ('cnt1', 'cnt2', 'x', 'y')[len(values):]:
                    values.append(mapped.pop(name))
                if mapped:
                    continue
            if (len(values) == 4 and all(type(value) is int for value in values)
                    and 1 <= values[0] <= 3 and 1 <= values[1] <= 3
                    and tuple(values[2:]) in ((2, 3), (2, 5), (3, 5))):
                return values
        except (ValueError, SyntaxError, KeyError, TypeError):
            pass
    return None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=PROJECT / 'runs/calibration-20261123/interaction-probe')
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    prompt = PROJECT / 'benchmark-data/codecontests/tasks/cf-483-B/public/prompt.txt'
    shutil.copyfile(prompt, output / 'public-statement.txt')
    for variant, expression in (('correct', 'lo'), ('seeded_off_by_one', 'lo - 1')):
        workspace = output / variant
        workspace.mkdir()
        for name, source in [('candidate.py', CANDIDATE.replace('RETURN_BOUNDARY', expression)),
                             ('check_contract.py', CONTRACT), ('grid_validate.py', GRID), ('replay.py', REPLAY)]:
            (workspace / name).write_text(source, encoding='utf-8')
    save(output / 'source-bundle.json', {
        'task': 'cf-483-B', 'public_source': str(prompt.relative_to(PROJECT)),
        'source_sha256': {str(path.relative_to(output)): hashlib.sha256(path.read_bytes()).hexdigest()
                          for path in output.glob('*/*.py')},
        'legal_domain': 'Positive counts; cnt1+cnt2<=1e9; distinct primes 2<=x<y<=30000.',
        'bounded_probe_domain': 'cnt1,cnt2 in 1..3; prime pairs (2,3),(2,5),(3,5): 27 legal inputs.',
        'property': 'allocation_feasible(result) and not allocation_feasible(result-1)',
        'limits': {'wrapper_seconds': 30, 'per_condition_seconds': 10, 'per_path_seconds': 5},
        'candidate_link': 'Sidecar imports and calls candidate.minimum_v; no copied search algorithm in sidecar.',
        'mutation': 'Only change is actual candidate return lo -> lo - 1.',
        'uses_hidden_tests': False, 'uses_reference_solutions': False, 'model_api_calls': 0,
    })
    started = time.monotonic()
    commands = [('unannotated_correct', 'correct',
                 'crosshair check --analysis_kind=PEP316,asserts --report_all --per_condition_timeout 10 --per_path_timeout 5 candidate.py'),
                ('prepared_correct', 'correct', 'verify check_contract.py'),
                ('prepared_mutant', 'seeded_off_by_one', 'verify check_contract.py')]
    checks = {}
    for name, variant, command in commands:
        result = run_isolated(output / variant, command, image=VERIFIER_IMAGE, timeout=35)
        checks[name] = {'command': command, **result}
        save(output / (name + '.json'), checks[name])
        print(json.dumps({'check': name, 'returncode': result['returncode'], 'elapsed_seconds': result['elapsed_seconds'],
                          'stdout': result['stdout'], 'stderr': result['stderr']}), flush=True)
    grids = {}
    for variant in ('correct', 'seeded_off_by_one'):
        executed = run_isolated(output / variant, 'python -B grid_validate.py', image=BASE_IMAGE, timeout=30)
        save(output / (variant + '-grid.json'), executed)
        if executed['returncode'] != 0:
            raise RuntimeError('Independent grid validation failed: ' + variant)
        grids[variant] = json.loads(executed['stdout'])
    detected = checks['prepared_mutant']['stdout'] + '\n' + checks['prepared_mutant']['stderr']
    case = parsed_counterexample(detected)
    provenance = 'parsed_crosshair_counterexample' if case else 'preselected_legal_fixture_not_a_crosshair_replay'
    case = case or [1, 1, 2, 3]
    replay_result = run_isolated(output / 'seeded_off_by_one', 'python -B replay.py', image=BASE_IMAGE,
                                 timeout=20, input_text=json.dumps(case))
    save(output / 'ordinary-python-replay.json', {'case_source': provenance, **replay_result})
    if replay_result['returncode'] != 0:
        raise RuntimeError('Ordinary Python fixture inspection failed')
    replay = json.loads(replay_result['stdout'])
    given = ' '.join(map(str, case)) + '\n'
    tests = {'input': [given], 'output': [str(replay['enumeration_oracle_v']) + '\n']}
    evaluations = {}
    for variant in ('correct', 'seeded_off_by_one'):
        evaluations[variant] = evaluate_python(output / variant / 'candidate.py', tests,
                                               output / (variant + '-public-fixture-evaluation'), 'integer_tokens')
        save(output / (variant + '-fixture-evaluation.json'), evaluations[variant])
    report = {'kind': 'CPU-only engineered interaction diagnostic; not an agent effectiveness experiment',
              'bounded_legal_inputs': 27, 'crosshair_checks': checks, 'independent_grid_validation': grids,
              'fixture_source': provenance, 'ordinary_python_fixture': replay,
              'existing_evaluator_on_same_public_domain_fixture': {key: value['passed'] for key, value in evaluations.items()},
              'total_elapsed_seconds': time.monotonic() - started,
              'limitations': ['Seeded off-by-one bug is intentional; this does not estimate naturally occurring bug frequency or agent improvement.',
                              'Only 27 legal inputs are in the contract domain; no claim about the full CF input space.',
                              'The feasibility specification is hand-prepared and independently enumerated only on this bounded grid.',
                              'Any agent comparison using this prepared specification must give it to both arms.',
                              'A timeout, no entrypoints, or Not confirmed is not a successful proof.']}
    save(output / 'report.json', report)
    text = ['# CPU-only interaction probe', '',
            'Public CF483B; hand-written binary search, one seeded return-boundary mutation, and a sidecar importing the actual candidate.', '',
            'The contract covers only counts 1..3 and prime pairs (2,3), (2,5), (3,5): 27 legal inputs.', '']
    for name, value in checks.items():
        text.extend([f'## {name}', '', f'Command: `{value["command"]}`',
                     f'Return code {value["returncode"]}; {value["elapsed_seconds"]:.3f} seconds.', '',
                     '```text', value['stdout'] + value['stderr'], '```', ''])
    text.extend(['## Independent validation and replay', '',
                 f'Feasibility formula: {grids["correct"]["independent_feasibility_formula_checks"]} checks against explicit set allocation.',
                 f'Correct candidate matches exhaustive oracle on {grids["correct"]["candidate_matches"]}/27 inputs; mutant on {grids["seeded_off_by_one"]["candidate_matches"]}/27.',
                 f'Fixture provenance: `{provenance}`.', '', '```json', json.dumps(replay, indent=2), '```', '',
                 f'Existing evaluator accepts correct candidate: {evaluations["correct"]["passed"]}; accepts mutant: {evaluations["seeded_off_by_one"]["passed"]}.', '',
                 '## Limits', '', *['- ' + item for item in report['limitations']]])
    (output / 'README.md').write_text('\n'.join(text) + '\n', encoding='utf-8')
    print(json.dumps({'report': str(output / 'report.json'), 'fixture_source': provenance,
                      'ordinary_python_fixture': replay, 'total_elapsed_seconds': report['total_elapsed_seconds']}), flush=True)


if __name__ == '__main__':
    main()
