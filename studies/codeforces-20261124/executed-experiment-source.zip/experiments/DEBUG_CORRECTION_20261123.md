Calibration correction — 23 November 2026

The initial API adapter concatenated every assistant message in one Responses
output. The API can return commentary messages and a separate `final_answer`.
Some commentary messages contained shell code blocks, so a valid final command
was rejected as a multiple-command format error. The model could then assume
that the rejected implementation had already been written. This produced empty
submissions and made the initial model scores unsuitable for comparison.

The initial `model-screen` and `paired-calibration` controllers were stopped.
Their raw requests, responses, trajectories, submissions and scores are retained
under `runs/calibration-20261123/`. All their outcomes are excluded from model
selection, success intervals and runtime forecasts. Their recorded charges and
maximum reservations for interrupted in-flight calls remain in the shared $15
calibration spending ledger.

The corrected adapter selects the sole `final_answer`, preserves assistant phase
when replaying messages, and never executes commentary-only or ambiguous output.
A rejected format explicitly tells the model that NO COMMANDS EXECUTED. Regression
tests cover the actual commentary-plus-final structure, incomplete responses,
multiple finals, legacy unphased responses and phase replay.

Clean `model-screen-v2` and `paired-calibration-v2` batches use the corrected
adapter, 16,384 maximum output tokens per request, medium reasoning effort,
twelve turns, a 300-second overall solve limit, and the same $0.28 run cap.
Network request time is bounded by the remaining solve time; a request timing
out at that limit is recorded as budget exhaustion and its last source is scored.
The screen has 3 models × 6 development tasks × 2 repetitions. Paired calibration
has GPT-5.6 Luna × 10 development tasks × 3 repetitions × 2 arms. These calibration
tasks remain separate from the untouched main selection.

The v2 guided runs exposed a second issue: an intended write/check could appear
in commentary while the final answer proposed a later test or submission. Taking
only the final message omitted the earlier action. All v2 batches were therefore
stopped and retained as debugging data as well. They are excluded from performance,
intervals and runtime forecasts, while all charges/reservations remain counted.

The v3 mini-SWE adapter now selects the FIRST fully closed command block across
chronological assistant messages, executes only that action, and replays only the
prefix through that command with its original phase. All later proposals are
discarded; the next observation explicitly says so if necessary. The prompt tells
the model to stop at one action and wait for actual output. General API text
extraction remains final-answer aware. Regression tests cover the actual sequence
of a proposed write, a real execution observation, and then a subsequent check.
The v3 solve ceiling is 600 seconds with twelve turns and 16,384 request output
tokens. A fresh paid smoke check precedes the replacement calibration batches.

The user explicitly requested BOTH optional access and a guided workflow. The
three main conditions will share one baseline, with two prespecified contrasts:
optional-minus-baseline and guided-minus-baseline. Main contrast intervals use
97.5% coverage each (Bonferroni for two comparisons), alongside descriptive 95%
per-arm intervals. V3 calibration uses two independent repetitions per task;
the preferred main design retains three, subject to measured time and budget.

GPT-5.6 Luna was selected for paired engineering calibration from the colleague's
existing setup, before inspecting any corrected verifier advantage. The main
model, final budget and sample size remain decisions to freeze after calibration.
