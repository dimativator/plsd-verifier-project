Current handoff: runs/split-rounds-main-20261123-v4/protocol/plan.json. Five full repetitions on the same100 tasks: ours1–3, colleague4–5, all three conditions. Shared key, combined main cap140USD split84/56, preparation~5.50USD, overall ceiling150USD. The older six-round/two-key packages below are superseded. Report overall round scores, mean, SD, variance and task-family confidence intervals.

Current distributed study (23 November)

The current frozen protocol is runs/distributed-main-20261123-v3/protocol/plan.json.
It contains 100 source families, six full repetitions and three conditions: 1800 runs.
Whole-family allocation is 60 here/40 with the colleague, caps $140/$95 and
$0.12 per run. Both verifier conditions share the same technical workflow and
guide. Optional use is discretionary; instructed use asks for an adaptive
plan/check/interpret/respond/recheck/coverage/close loop. Task statements, tests
and blank initial main.py remain unchanged. Actual compliance is measured; it is
not assumed or used to filter correctness outcomes.

Report full-repetition overall scores, their mean, sample SD/variance (ddof1) and
paired family confidence intervals. Distributed inference is conditional on the
fixed host allocation and resamples families within host×rating strata. Results
from all workers are merged against the central manifest before calculating
whole-benchmark scores. Do not count host subtotals as repetitions.

The submission controller accepts the literal echo marker and pure cd /work &&
echo marker form. A marker printed in another action receives the actionable
notice, without blocking ordinary command chaining. Historical v2 proposal and
resource figures below are superseded; retain their source archives/results.
No main run has started during preparation. For the Windows colleague package,
follow START_HERE.md, SETUP.ps1, RUN.ps1 and COLLECT.ps1 at the package root.

Experiment preparation and repeated evaluation

This package validates tasks, controls OpenAI API spending, runs mini-SWE-agent in
isolated Docker containers, and computes uncertainty over source task families.
The original pilot code and benchmark source files remain unchanged.

Current prompt-only workflow (23 November)

The v2 general guide is embedded in both verifier condition prompts and remains
available as /opt/plinse/CROSSHAIR_GUIDE.txt. Optional use stays optional. Guided
agents are asked to check task-derived behavior of actual answer-producing code,
explain their chosen property/scope, and interpret the returned observation.
Agents choose their own helpers, contracts, adapters and local checks. Statements,
examples, task tests and blank initial main.py remain unchanged; no task-specific
solver interface, contract, oracle or verify_solution tool is supplied.

The guide teaches importing the actual implementation, independent bounded
checks, counterexample legality/replay, empty and inconclusive results, assertion
assumptions, and the need to check called-function contracts themselves. Its
displayed synthetic example passed all 11 CPU qualification checks. Outputs:
runs/calibration-20261123/guidance-smoke/exact-guide-v2/.

Two completed development pilots are preserved separately: prompt-guidance-v1
(24 resolved runs, including six external controller-interruption replacements)
and prompt-guidance-v2 (16 optional/guided runs). Both have two repetitions on the
same four exposed families. They assess interaction feasibility, not efficacy.
Combined new-pilot accounting is $0.78384085, including retained interrupted
reservations. The latest model charges averaged about $0.014 per verifier-arm
run. Reports/audits live under their run roots; historical v3 figures below used
different prompts and 12 steps.

The external-failure resolver retains each batch's explicit frozen spend caps
and refuses a ledger with different caps. recover_interrupted.py separately
preserves raw partial attempts after a stopped controller, records one recovery
claim per missing identity, and emits one selected result per original identity.
Use a unique output-directory basename for batches sharing a spend ledger,
because run IDs include that basename. Never count an external replacement as
another independent repetition.

The fresh main proposal is runs/main-20261123-guidance-v2-proposed/: 100 families,
three repetitions, three arms, 100 steps, 600 solve-seconds and eight workers.
Its 900 planned runs have a $108 model ceiling at $0.12/run; a separate $115
ledger includes external-retry headroom. It is prepared only, not launched.

The controller reads the parent workspace's Git-ignored .env file. The API key
never enters agent containers or manifests. All preparation uses the shared
runs/calibration-20261123/spend ledger, with a $15 total cap including debugging,
retries and conservative reservations for interrupted requests.

For new runs the step safety limit is now 100, as requested by the user. Dollar
and overall wall-time limits remain separate. The completed v3 preparation below
used the historical 12-step limit; reproduce it with the frozen source archive
and explicit --step-limit 12 rather than mixing it with the revised configuration.

Setup from the repository (PowerShell):

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install mini-swe-agent==2.4.6
docker build --target base -t plinse-eval:20261123 -f experiments/Dockerfile experiments
docker build --target crosshair -t plinse-crosshair:20261123 -f experiments/Dockerfile experiments
```

Containers have no network, a read-only root, no Linux capabilities, bounded
output, one CPU, one GiB RAM and only their own public workspace mounted. Hidden
expected outputs stay on the controller. Source hashes, prompt hashes, image IDs,
model settings and spend limits are saved in expected.json. The installed
controller lock is saved in the run root.

The v3 action contract executes exactly the FIRST complete fenced command in the
model's chronological messages and returns its real observation. Later proposals
are discarded and never replayed as executed. See DEBUG_CORRECTION_20261123.md for
excluded initial/v2 adapter-debugging runs; their outcomes are not performance
data, and their charges still count against preparation spending.

V3 preparation uses medium effort, 16,384 maximum output tokens per request,
twelve turns and 600 seconds solving time. The calibration run cap is $0.28.
A transient API retry is allowed only within the remaining solve deadline.
Budget/step/time exits score the final saved implementation. Formatting errors
and wrong answers are not retried as infrastructure failures.

```powershell
.\.venv\Scripts\python.exe -m experiments.run --output runs/calibration-20261123/model-screen-v3 --models gpt-6-luna gpt-5.6-luna gpt-6.1-sol --conditions baseline --repetitions 2 --task-count 4 --workers 4 --phase model_screen --step-limit 12
.\.venv\Scripts\python.exe -m experiments.run --output runs/calibration-20261123/paired-calibration-v3 --models gpt-5.6-luna --conditions baseline verifier --repetitions 2 --task-count 10 --workers 4 --phase calibration --step-limit 12
.\.venv\Scripts\python.exe -m experiments.run --output runs/calibration-20261123/guided-calibration-v3 --models gpt-5.6-luna --conditions guided_verifier --repetitions 2 --task-count 10 --workers 4 --phase calibration --step-limit 12
```

The two GPT-5.6 Luna calibration batches form three arms with one shared baseline:
public tools only, optional CrossHair access, and a guided workflow asking for a
relevant verifier attempt and inspection of its feedback. The model was chosen
from the colleague's prior setup, not from observed verifier advantage. Coding
agents may invoke CrossHair directly, so wrapper markers alone undercount usage;
process_audit.py also reports direct command observations and their limits.

Use a new batch directory when changing source/settings. A completed batch can
resume only against the same manifest; inspect incomplete attempts first.
External failed attempts must be preserved and resolved explicitly, not dropped.

```powershell
.\.venv\Scripts\python.exe -m experiments.three_arm_analysis --results runs/calibration-20261123/paired-calibration-v3 runs/calibration-20261123/guided-calibration-v3 --expected runs/calibration-20261123/paired-calibration-v3/expected.json runs/calibration-20261123/guided-calibration-v3/expected.json --phase calibration --output runs/calibration-20261123/three-arm-analysis-v3.json
.\.venv\Scripts\python.exe -m experiments.process_audit --results runs/calibration-20261123/paired-calibration-v3 runs/calibration-20261123/guided-calibration-v3 --output runs/calibration-20261123/process-audit-v3.json
.\.venv\Scripts\python.exe -m experiments.calibration_report --root runs/calibration-20261123
```

Task selection/reference-check instructions are in validation_readme.md. The run
root's source-quality.md explains the small upstream private suites and invalid
generated tests found in domain probes. Success means passing the packaged private
suite; it does not establish Codeforces judge acceptance or full-domain coverage.
Statistical details are in analysis_readme.md. Main comparisons use task-averaged
repetitions, source-family bootstrap intervals, and two prespecified contrasts:
optional-minus-baseline and guided-minus-baseline. Each main contrast receives a
97.5% interval (Bonferroni for two comparisons), with descriptive 95% arm intervals.

Tests:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s experiments -p "test_*.py" -v
$env:PLINSE_DOCKER_TESTS='1'
.\.venv\Scripts\python.exe -m unittest experiments.test_runtime -v
```

Before main collection freeze the model/settings, three condition prompts,
validated tasks/families/tests, resource limits, rerun policy and analysis. The
preferred candidate is 100 families x 3 repetitions x 3 arms = 900 runs, conditional
on calibrated cost/time. A $0.12 identical run cap bounds those model charges at
$108. The fallback is 100 x 2 x 3 = 600 runs, at most $114 with a $0.19 cap. A changed
cap must permit the intended workflow before freezing. Calibration commands do
not launch a main experiment.
