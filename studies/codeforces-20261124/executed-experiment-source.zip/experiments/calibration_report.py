"""Render a concise report from completed validation/calibration artifacts.

This module reads JSON artifacts only. It never contacts a model, changes a
ledger, or treats development results as a main effectiveness experiment.
"""

from __future__ import annotations

import argparse
from collections import Counter
from decimal import Decimal, InvalidOperation, ROUND_DOWN
import json
import math
from pathlib import Path
from typing import Any


UNAVAILABLE = "unavailable"
CALIBRATION_ARMS = ("baseline", "verifier", "guided_verifier")


def _read(path: Path) -> dict | None:
    if not path.exists():
        return None
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError(f"Expected a JSON object in {path}")
    return value


def _numeric(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _n(value: Any, digits: int = 0) -> str:
    return f"{value:,.{digits}f}" if _numeric(value) else UNAVAILABLE


def _dollars(value: Any, digits: int = 2) -> str:
    return "$" + _n(float(value), digits) if isinstance(value, Decimal) or _numeric(value) else UNAVAILABLE


def _cell(value: Any) -> str:
    return str(value).replace("|", "\\|").replace("\n", " ")


def _table(headers: list[str], rows: list[list[Any]]) -> list[str]:
    return ["| " + " | ".join(map(_cell, headers)) + " |",
            "| " + " | ".join("---" for _ in headers) + " |",
            *["| " + " | ".join(map(_cell, row)) + " |" for row in rows]]


def _family(task: dict) -> str:
    return task.get("family_id", task.get("family", task.get("id", "")))


def _families(tasks: list[dict]) -> set[str]:
    return {_family(task) for task in tasks}


def _sum_field(rows: list[dict], field: str) -> int | None:
    values = [row.get(field) for row in rows]
    return sum(values) if all(isinstance(value, int) for value in values) else None


def _ledger_summary(ledger: dict | None) -> dict:
    if ledger is None:
        return {"available": False}
    reservations = ledger.get("reservations", {})
    if not isinstance(reservations, dict):
        raise ValueError("Ledger reservations must be an object")
    accounted, settled, upper, pending = (Decimal(0) for _ in range(4))
    for row in reservations.values():
        status = row.get("status")
        amount = Decimal(str(row["reserved"] if status == "pending" else row["charged"]))
        if not amount.is_finite() or amount < 0:
            raise ValueError("Ledger contains an invalid amount")
        accounted += amount
        if status == "settled":
            settled += amount
        elif status == "pending":
            pending += amount
        elif status in ("uncertain", "usage_upper_bound"):
            upper += amount
        elif status != "rejected":
            raise ValueError(f"Unknown reservation status: {status}")
    return {"available": True, "accounted": accounted, "settled": settled,
            "upper": upper, "pending": pending,
            "counts": Counter(row.get("status") for row in reservations.values()),
            "limit": ledger.get("limits", {}).get("total")}


def _model_ids(summary: dict | None, expected: dict | None) -> list[str]:
    return sorted(set((summary or {}).get("models", {})) |
                  {run["model"] for run in (expected or {}).get("runs", [])})


def _run_plan(expected: dict | None, model: str, condition: str) -> dict:
    runs = [r for r in (expected or {}).get("runs", []) if r.get("model") == model and r.get("condition") == condition]
    counts = Counter(r["task_id"] for r in runs)
    repetitions = next(iter(counts.values())) if counts and len(set(counts.values())) == 1 else None
    return {"runs": len(runs) if expected is not None else None,
            "tasks": len(counts) if expected is not None else None,
            "repetitions": repetitions, "repetition_counts_by_task": dict(counts)}


def _success(metrics: dict, complete: bool) -> str:
    if not complete:
        return "unavailable (incomplete)"
    interval = metrics.get("success_interval", {})
    estimate = interval.get("estimate_percent", metrics.get("task_averaged_success_percent"))
    if not _numeric(estimate):
        return UNAVAILABLE
    level = interval.get("confidence_level", .95)
    bounds = interval.get("confidence_interval_percent", interval.get("ci95_percent"))
    label = "B"
    if bounds is None:
        bounds = interval.get("conservative_confidence_interval_percent", interval.get("conservative_ci95_percent"))
        label = "H"
    if isinstance(bounds, list) and len(bounds) == 2 and all(_numeric(v) for v in bounds):
        return f"{estimate:.1f}% [{bounds[0]:.1f}, {bounds[1]:.1f}] {_n(100 * level, 1)}% {label}"
    return f"{estimate:.1f}%; CI unavailable"


def _measured(metrics: dict, field: str, statistic: str = "mean") -> Any:
    distribution = metrics.get(field, {})
    if not metrics.get("scored_runs") or distribution.get("n") != metrics["scored_runs"]:
        return None
    value = distribution.get(statistic)
    return value if _numeric(value) else None


def _forecast(model_summary: dict, repetitions: int) -> dict | None:
    if not model_summary.get("complete"):
        return None
    conditions = model_summary.get("conditions", {})
    if any(c not in conditions for c in CALIBRATION_ARMS):
        return None
    collected = {}
    for statistic in ("mean", "p95"):
        for field in ("scored_run_cost_usd", "scored_solve_plus_evaluation_seconds"):
            values = [_measured(conditions[c], field, statistic) for c in CALIBRATION_ARMS]
            if any(value is None for value in values):
                return None
            collected[field, statistic] = 100 * repetitions * sum(values)
    return {"runs": 100 * len(CALIBRATION_ARMS) * repetitions,
            "cost_mean": collected["scored_run_cost_usd", "mean"],
            "cost_p95_envelope": collected["scored_run_cost_usd", "p95"],
            "serial_seconds_mean": collected["scored_solve_plus_evaluation_seconds", "mean"],
            "serial_seconds_p95_envelope": collected["scored_solve_plus_evaluation_seconds", "p95"]}


def _combined_calibration(optional: dict | None, guided: dict | None, combined: dict | None) -> dict:
    if combined is not None:
        if combined.get("phase") != "calibration":
            raise ValueError("Combined report input must be calibration, not main data")
        models = {name: {**values, "complete": bool(values.get("complete") and set(CALIBRATION_ARMS) <= set(values.get("conditions", {})))}
                  for name, values in combined.get("models", {}).items()}
        return {**combined, "models": models, "complete": bool(combined.get("complete") and models and all(m["complete"] for m in models.values()))}
    if any(source and source.get("phase") != "calibration" for source in (optional, guided)):
        raise ValueError("Calibration report inputs must not contain main-study results")
    models = {}
    for model in sorted(set((optional or {}).get("models", {})) | set((guided or {}).get("models", {}))):
        first = (optional or {}).get("models", {}).get(model, {})
        second = (guided or {}).get("models", {}).get(model, {})
        shared_conditions = set(first.get("conditions", {})) & set(second.get("conditions", {}))
        conditions = {**first.get("conditions", {}), **second.get("conditions", {})}
        models[model] = {"conditions": conditions,
                         "complete": bool(first.get("complete") and second.get("complete")
                                          and not shared_conditions and set(CALIBRATION_ARMS) <= set(conditions))}
    return {"models": models, "complete": bool(optional and optional.get("complete") and guided and guided.get("complete")
                                                 and models and all(m["complete"] for m in models.values()))}


def _process_lines(audit: dict | None, allowed_batches: set[str], model: str | None,
                   expected: dict) -> list[str]:
    runs = [row for row in (audit or {}).get("runs", [])
            if row.get("batch") in allowed_batches and (model is None or row.get("model") == model)]
    if not runs:
        return ["Tool-use process audit for the selected replacement calibration batches: **unavailable**. "
                "Earlier debug-batch audit rows are excluded.", ""]
    rows = []
    partial = False
    for condition in CALIBRATION_ARMS:
        observed = [row for row in runs if row.get("condition") == condition]
        count = _run_plan(expected, model or "", condition)["runs"]
        partial = partial or count != len(observed)
        diagnostics = Counter()
        for row in observed:
            diagnostics.update(row.get("diagnostic_call_counts", {}))
        rows.append([condition, f"{len(observed)}/{_n(count)}",
                     sum(bool(row.get("verifier_usage_observed")) for row in observed) if observed else UNAVAILABLE,
                     sum(row.get("observed_wrapper_start_count", 0) for row in observed) if observed else UNAVAILABLE,
                     sum(row.get("direct_cli_command_count", 0) for row in observed) if observed else UNAVAILABLE,
                     ", ".join(f"{name}={value}" for name, value in sorted(diagnostics.items())) or ("none observed" if observed else UNAVAILABLE),
                     sum(bool(row.get("source_changed_after_any_verifier_action")) for row in observed) if observed else UNAVAILABLE,
                     sum(bool(row.get("action_parse_errors") or row.get("marker_anomalies") or row.get("missing_actions_despite_reported_actions")) for row in observed) if observed else UNAVAILABLE])
    return [f"Host-captured tool-use audit for the selected calibration batches ({'partial' if partial else 'all planned records represented'}):", "",
            *_table(["Arm", "Audited/planned", "Runs with observed verify", "Wrapper starts", "Direct CLI commands", "Wrapper diagnostic calls", "Later source-change runs", "Runs with anomalies"], rows), "",
            "These counts come from captured host actions/output, not an intention written by the model. "
            "Verifier-use counts include wrapper or direct CLI evidence; the diagnostic-category column counts wrapper diagnostics. "
            "Output markers are observed text and can be spoofed; guide-read commands do not prove understanding. "
            "Later source changes are temporal evidence, not proof that feedback caused them, and reported counterexamples were not independently reproduced by this summary.", ""]


def build_report(screen: dict | None, calibration: dict | None, manifest: dict | None,
                 ledger: dict | None, *, screen_expected: dict | None = None,
                 calibration_expected: dict | None = None, model: str | None = None,
                 guided: dict | None = None, guided_expected: dict | None = None,
                 three_arm_summary: dict | None = None,
                 screen_directory: str = "model-screen-v3", paired_directory: str = "paired-calibration-v3",
                 guided_directory: str = "guided-calibration-v3",
                 source_quality: dict | None = None, source_quality_md_available: bool = False,
                 process_audit: dict | None = None, process_audit_source: str | None = None,
                 domain_audit: dict | None = None, trace_notes_available: bool = False,
                 cap_replay: dict | None = None, cap_replay_source: str | None = None,
                 main_budget_usd: Decimal = Decimal("115"), total_budget_usd: Decimal = Decimal("150"),
                 run_cap_usd: Decimal = Decimal("0.12"), r2_run_cap_usd: Decimal = Decimal("0.19"),
                 reserve_usd: Decimal = Decimal("15"),
                 buffer_usd: Decimal = Decimal("5"), hours_available: float | None = None) -> str:
    """Build Markdown; unavailable/incomplete artifacts never become estimates."""
    calibration = _combined_calibration(calibration, guided, three_arm_summary)
    arm_expected = {"runs": (calibration_expected or {}).get("runs", []) + (guided_expected or {}).get("runs", [])}
    optional_config = (calibration_expected or {}).get("config", {})
    guided_config = (guided_expected or {}).get("config", {})
    incompatible = [field for field in ("max_output_tokens", "effort", "step_limit", "solve_limit_seconds")
                    if field in optional_config and field in guided_config and optional_config[field] != guided_config[field]]
    if incompatible:
        calibration = {**calibration, "complete": False, "models": {
            name: {**values, "complete": False} for name, values in calibration.get("models", {}).items()}}
    screen_complete = bool(screen and screen.get("complete"))
    calibration_complete = bool(calibration and calibration.get("complete"))
    lines = ["Validation and calibration report", "",
             f"Model-screen completion: **{'complete' if screen_complete else 'unavailable or incomplete'}**. "
             f"Three-arm calibration completion: **{'complete' if calibration_complete else 'unavailable or incomplete'}**. "
             "These are development results; no main effectiveness result is reported.", "",
             f"Performance summaries read only `{screen_directory}/`, `{paired_directory}/` and `{guided_directory}/` (or their combined three-arm summary). "
             "All earlier unversioned and v2 batches are excluded from performance. API response/action-phase handling could ignore an earlier proposed "
             "write or verifier action while presenting a later action, producing phantom execution state. "
             "Their charges remain included in the shared spend ledger. The v3 protocol executes the first complete action in message order, "
             "retains only the conversation prefix through that action, and waits for its real observation before the next model turn.", ""]

    main_tasks = (manifest or {}).get("tasks", (manifest or {}).get("main_tasks", []))
    calibration_tasks = (manifest or {}).get("calibration_tasks", [])
    reserves = (manifest or {}).get("reserves", [])
    if manifest:
        preflight = manifest.get("reference_preflight_summary", {})
        lines += [f"Source-reference preflight passed **{_n(preflight.get('passed'))}/{_n(preflight.get('attempted'))}** candidates. "
                  "Only passed candidates enter the validated selections. Original private tests are used; unreviewed generated tests are excluded. "
                  "Passing preserved source references is a sanity check, not an independent proof of oracle correctness.", ""]
        lines += _table(["Validated group", "Tasks", "Source families", "Private cases"], [
            ["Main", len(main_tasks), len(_families(main_tasks)), _n(_sum_field(main_tasks, "private_test_count"))],
            ["Reserves", len(reserves), len(_families(reserves)), _n(_sum_field(reserves, "private_test_count"))],
            ["Calibration", len(calibration_tasks), len(_families(calibration_tasks)), _n(_sum_field(calibration_tasks, "private_test_count"))],
        ])
        overlap = _families(main_tasks) & _families(calibration_tasks)
        bands = Counter(task.get("rating_band", "missing") for task in main_tasks)
        lines += ["", "Main rating allocation: " + ", ".join(f"{band}: {count}" for band, count in sorted(bands.items()))
                  + f". Main/calibration family overlap: **{len(overlap)}**.", ""]
    else:
        overlap = set()
        lines += ["Validated task manifest and source-reference totals: **unavailable**.", ""]

    if source_quality:
        coverage = source_quality.get("main_coverage", {})
        lines += [f"Source-quality audit: the median task's largest private input is {_n(coverage.get('median_task_max_private_input_chars'), 1)} characters; "
                  f"the global maximum is {_n(coverage.get('max_private_input_chars'))}; "
                  f"{_n(coverage.get('tasks_max_private_input_below_100_chars'))}/{_n(coverage.get('tasks'))} tasks have no private input reaching 100 characters. "
                  "Two direct pinned-source probes found the small private suites unchanged upstream; this does not verify all tasks against the full official judge. "
                  "Character length is only a structural proxy. The endpoint is **success on the packaged original source-private tests**; "
                  "its CI does not cover missing-test uncertainty, full-domain correctness, Codeforces acceptance, or asymptotic efficiency.", ""]
        probes = source_quality.get("probe_domain_checks", {})
        invalid = [f"`{task}`: {_n(data['generated'].get('invalid_case_count'))}/{_n(data['generated'].get('case_count'))}"
                   for task, data in sorted(probes.items()) if isinstance(data.get("generated"), dict)]
        if invalid:
            lines += ["Statement-invalid generated cases in the targeted probes: " + "; ".join(invalid)
                      + ". These are task-specific checks, not a semantic audit of every suite. Unreviewed generated tests remain excluded.", ""]
    else:
        lines += ["Source-quality numerical audit: **unavailable**. Packaged private-test success alone does not establish full-domain correctness or full Codeforces judge acceptance.", ""]
    if source_quality_md_available:
        lines += ["See [source-quality.md](source-quality.md) for the source-coverage evidence and its limits.", ""]

    screen_config = (screen_expected or {}).get("config", {})
    calibration_config = (calibration_expected or {}).get("config", {})
    lines += [f"The baseline-only model screen uses {_n(screen_config.get('max_output_tokens'))} maximum output tokens per request. "
              f"Paired calibration uses {_n(calibration_config.get('max_output_tokens'))} and effort `{calibration_config.get('effort', UNAVAILABLE)}`. "
              f"Guided calibration records {_n(guided_config.get('max_output_tokens'))} and effort `{guided_config.get('effort', UNAVAILABLE)}`. "
              f"Recorded solve ceilings are {_n(screen_config.get('solve_limit_seconds'))} seconds for the screen and "
              f"{_n(calibration_config.get('solve_limit_seconds'))} seconds for paired calibration. "
              "The v3 protocol allows at most **one deadline-aware transient request retry** (max_retries=1), "
              "recomputing request timeouts from the remaining overall solve deadline; there is no unbounded retry loop. "
              "The batches have separate development purposes and task coverage: their baseline outcomes are kept separate even when settings agree. "
              "Model-screen intervals are exploratory and do not adjust for using those development families in model comparison.", ""]
    screen_rows = []
    for model_id in _model_ids(screen, screen_expected):
        summary = (screen or {}).get("models", {}).get(model_id, {})
        metrics = summary.get("conditions", {}).get("baseline", {})
        plan = _run_plan(screen_expected, model_id, "baseline")
        complete = bool(summary.get("complete"))
        mean_cost = _measured(metrics, "scored_run_cost_usd") if complete else None
        solve = _measured(metrics, "scored_solve_seconds") if complete else None
        evaluation = _measured(metrics, "scored_evaluation_seconds") if complete else None
        screen_rows.append([model_id, f"{_n(metrics.get('scored_runs'))}/{_n(plan['runs'])}",
                            f"{_n(plan['tasks'])} × {_n(plan['repetitions'])}", _success(metrics, complete),
                            _dollars(mean_cost, 4), f"{_n(solve, 1)} / {_n(evaluation, 1)}"])
    lines += _table(["Screen model", "Scored/planned runs", "Tasks × reps", "Success [CI, coverage]", "Mean $/run", "Mean solve/eval s"], screen_rows or [[UNAVAILABLE] * 6])
    lines += ["", "B = stratified family-bootstrap CI; H = conservative Hoeffding fallback when the bootstrap degenerates. "
              "Repeated runs retain the source-family count shown by the task allocation; with only four screen families, nominal bootstrap coverage is unreliable. Apparent narrowness is not strong evidence of precision; this screen supports availability, rough cost/runtime and floor/ceiling checks rather than reliable model rankings.", ""]

    calibration_models = _model_ids(calibration, arm_expected)
    selected = model or (calibration_models[0] if len(calibration_models) == 1 else None)
    selected_summary = (calibration or {}).get("models", {}).get(selected, {})
    selected_complete = bool(selected_summary.get("complete"))
    condition_metrics = selected_summary.get("conditions", {})
    lines += [f"Three-arm calibration model: **{selected or UNAVAILABLE}**. "
              "It was preselected using the colleague's prior pilot context, rather than declared the winner of this small screen. "
              "Its per-arm success remains exploratory; the calibration families are excluded from the main study.", ""]
    arm_rows = []
    for condition in CALIBRATION_ARMS:
        metrics = condition_metrics.get(condition, {})
        plan = _run_plan(arm_expected, selected or "", condition)
        complete = selected_complete and bool(metrics)
        arm_rows.append([condition, f"{_n(metrics.get('scored_runs'))}/{_n(plan['runs'])}",
                         f"{_n(plan['tasks'])} × {_n(plan['repetitions'])}", _success(metrics, complete),
                         _dollars(_measured(metrics, "scored_run_cost_usd") if complete else None, 4),
                         _dollars(_measured(metrics, "scored_run_cost_usd", "p95") if complete else None, 4),
                         _n(_measured(metrics, "scored_solve_plus_evaluation_seconds") if complete else None, 1),
                         _n(metrics.get("budget_exhausted_scored_runs"))])
    lines += _table(["Arm", "Scored/planned", "Tasks × reps", "Success [CI, coverage]", "Mean $/run", "p95 $/run", "Mean solve+eval s", "Budget exits"], arm_rows)
    baseline = condition_metrics.get("baseline", {}).get("task_averaged_success_percent")
    verifier = condition_metrics.get("verifier", {}).get("task_averaged_success_percent")
    guided_success = condition_metrics.get("guided_verifier", {}).get("task_averaged_success_percent")
    baseline_plan = _run_plan(arm_expected, selected or "", "baseline")
    verifier_plan = _run_plan(arm_expected, selected or "", "verifier")
    guided_plan = _run_plan(arm_expected, selected or "", "guided_verifier")
    same_tasks = bool(baseline_plan["repetition_counts_by_task"]) and baseline_plan["repetition_counts_by_task"] == verifier_plan["repetition_counts_by_task"] == guided_plan["repetition_counts_by_task"]
    delta = verifier - baseline if selected_complete and same_tasks and _numeric(baseline) and _numeric(verifier) else None
    guided_delta = guided_success - baseline if selected_complete and same_tasks and _numeric(baseline) and _numeric(guided_success) else None
    lines += ["", f"Descriptive calibration point differences: optional minus baseline **{_n(delta, 1)} pp**; "
              f"guided minus baseline **{_n(guided_delta, 1)} pp**. "
              "These are exploratory differences across the same development families, with no main treatment-effect CI or causal conclusion. "
              "Budget-exhausted runs are scored on the last saved source and remain in their assigned arm. "
              "Unresolved infrastructure failures and missing planned outcomes block completed-data summaries.", ""]
    exploratory_rows = []
    for name, contrast in calibration.get("exploratory_contrasts", {}).items():
        result = contrast.get("models", {}).get(selected, {})
        interval = result.get("difference_percentage_points", {})
        bounds = interval.get("confidence_interval")
        method = "B"
        if bounds is None:
            bounds = interval.get("conservative_confidence_interval")
            method = "H"
        interval_text = (f"[{bounds[0]:.1f}, {bounds[1]:.1f}] {_n(100 * interval.get('confidence_level', contrast.get('confidence_level', .975)), 1)}% {method}"
                         if isinstance(bounds, list) and len(bounds) == 2 else UNAVAILABLE)
        exploratory_rows.append([name, _n(result.get("family_count")), _n(interval.get("estimate"), 1), interval_text])
    if exploratory_rows:
        lines += ["Explicitly requested **exploratory paired development intervals**:", "",
                  *_table(["Development contrast", "Source families", "Difference pp", "Paired interval pp [coverage]"], exploratory_rows), "",
                  "These paired intervals retain task/family matching and repeated outcomes, but the development outcomes were already inspected. "
                  "The small family count limits coverage/precision; neither the adjustment nor a nonzero interval turns calibration into confirmatory main evidence. "
                  "Both contrasts use the same prespecified 97.5% interval procedure.", ""]
    if incompatible:
        lines += ["Calibration settings mismatch blocks combined estimates: " + ", ".join(incompatible) + ".", ""]
    lines += ["The main study has two co-primary contrasts against one shared baseline: optional verifier access versus baseline, "
              "and guided verification workflow versus baseline. Use a two-sided **97.5% interval per contrast** "
              "(Bonferroni) for approximately 95% familywise coverage with bootstrap intervals. "
              "The descriptive per-arm intervals above keep their own reported coverage and do not replace those adjusted main contrasts.", ""]
    lines += _process_lines(process_audit, {Path(paired_directory).name, Path(guided_directory).name}, selected, arm_expected)
    if domain_audit:
        legal = domain_audit.get("is_legal_task_counterexample")
        unchanged = domain_audit.get("executable_ast_unchanged_after_removing_docstrings")
        final_score = domain_audit.get("hidden_passed")
        lines += [f"Legal-domain trace audit — `{domain_audit.get('task', UNAVAILABLE)}`, repetition {_n(domain_audit.get('repetition'))}: "
                  + ("the reported CrossHair exception is **outside the task's legal input domain**. " if legal is False else "consult the recorded domain-audit conclusion before interpreting the reported exception. ")
                  + str(domain_audit.get("reason", "")) + " "
                  + ("The agent added alphabet preconditions; the executable AST was unchanged after removing docstrings. " if unchanged is True else "Executable-program equivalence is not established by this summary. ")
                  + ("The final submission still failed the packaged hidden tests. " if final_score is False else "")
                  + "This is a contract-domain correction, **not demonstrated legal-input algorithm repair or a correctness boost**. "
                  + f"See `{guided_directory}/counterexample-domain-audit.json`.", ""]
    if trace_notes_available:
        lines += [f"The representative [guided trace notes]({guided_directory}/TRACE_NOTES.md) document inconclusive/no-entrypoint checks "
                  "and weak or restricted properties; zero tool exit status does not establish a proof. They also document scratch-file loss "
                  "because action containers had ephemeral `/tmp` during calibration. The prepared main runtime now preserves `/tmp` "
                  "within each agent workspace, and a two-action Docker fixture passed; hidden evaluation retains a fresh private temporary directory. "
                  "Calibration outcomes remain unchanged, and the frozen v3 archive matches their recorded core source hashes. "
                  "This environment improvement makes direct cost/time extrapolation provisional.", ""]

    accounting = _ledger_summary(ledger)
    remaining = None
    if accounting["available"]:
        remaining = max(Decimal(0), total_budget_usd - accounting["accounted"])
        available_main = min(main_budget_usd, max(Decimal(0), remaining - reserve_usd - buffer_usd))
        lines += [f"The shared ledger accounts for **{_dollars(accounting['accounted'], 4)}**, including "
                  f"{_dollars(accounting['settled'], 4)} settled usage, {_dollars(accounting['upper'], 4)} conservative upper bounds "
                  f"and {_dollars(accounting['pending'], 4)} pending reservations. "
                  "This includes smoke runs and earlier attempts, rather than only resolved experiment rows. "
                  f"At a {_dollars(total_budget_usd)} total allocation, the ledger-based remaining amount is {_dollars(remaining)}; "
                  f"after a {_dollars(reserve_usd)} operational reserve and {_dollars(buffer_usd)} buffer, "
                  f"the proposed main allocation is at most **{_dollars(available_main)}**. "
                  "This is ledger accounting, not an independently checked API account balance.", ""]
    else:
        available_main = None
        lines += ["Shared spend ledger, remaining budget and affordable main allocation: **unavailable**.", ""]
    replay = (cap_replay or {}).get("models", {}).get(selected, {})
    if replay:
        frontier = Decimal(str(replay["max_required_cap_usd"]))
        replay_cap = Decimal(str(cap_replay["proposed_cap_usd"]))
        lines += [f"Recorded reservation-frontier replay for `{selected}`: **{_n(replay.get('recorded_runs_fitting_proposed_cap'))}/"
                  f"{_n(replay.get('completed_runs'))}** completed runs fit {_dollars(replay_cap)}; the maximum accounted-plus-next-request "
                  f"frontier was {_dollars(frontier, 6)}. "
                  "This replay supports cap feasibility for those recorded runs, not a guarantee for unseen main tasks, "
                  "changed runtime settings, or subsequent retries. "
                  + (f"Source: `{cap_replay_source}`." if cap_replay_source else ""), ""]

    forecasts = {reps: _forecast(selected_summary, reps) for reps in (2, 3)}
    forecast_rows = []
    for reps, estimate in forecasts.items():
        option_cap = run_cap_usd if reps == 3 else r2_run_cap_usd
        ceiling = option_cap * (300 * reps)
        forecast_rows.append([f"100 × {reps} × 3", 300 * reps,
                              _dollars(estimate["cost_mean"] if estimate else None),
                              _dollars(estimate["cost_p95_envelope"] if estimate else None),
                              _n(estimate["serial_seconds_mean"] / 3600 if estimate else None, 2),
                              (f"{_n(estimate['serial_seconds_mean'] / 4 / 3600, 2)} / {_n(estimate['serial_seconds_p95_envelope'] / 4 / 3600, 2)}" if estimate else UNAVAILABLE),
                              (f"{_n(estimate['serial_seconds_mean'] / 8 / 3600, 2)} / {_n(estimate['serial_seconds_p95_envelope'] / 8 / 3600, 2)}" if estimate else UNAVAILABLE),
                              _dollars(option_cap), _dollars(ceiling)])
    lines += ["Main forecasts use the three replacement calibration arms separately, with the baseline counted once:", ""]
    lines += _table(["Families × reps × arms", "Runs", "Mean-based API $", "p95/run planning envelope $", "Mean serial worker h", "Ideal c4 h: mean / p95 envelope", "Ideal c8 h: mean / p95 envelope", "Proposed cap/run", "Model-charge ceiling"], forecast_rows)
    lines += ["", "The p95 figures scale observed per-run p95 values; they are not the p95 of total spending/runtime or confidence bounds. "
              "Small calibration samples can miss costly/slow tails. Forecasts exclude setup, additional infrastructure reruns and report preparation; "
              "within-run request retry charges present in the measured records are already counted. They "
              "assume the calibration task mix, prompts and budgets represent the main workload. "
              "Model amounts tagged as upper bounds are conservative estimates, not exact billed spend.", "",
              "c4/c8 divide measured serial worker time by four/eight; they do not measure throughput at those concurrency levels. "
              "The current runtime limits each active container to one CPU and 1 GiB. Eight simultaneous workers can increase CPU/memory "
              "contention and require up to eight container memory allocations. c8 is an optional unmeasured scenario, not a promised speedup. "
              "The v3 setup uses four agent workers per batch across separate concurrent batch pools (up to twelve agent slots); "
              "agent slots are not a measurement of simultaneous active containers or sustained main throughput.", ""]
    solve_cap = calibration_config.get("solve_limit_seconds")
    if _numeric(solve_cap):
        lines += [f"Nominal solve-budget envelope at {_n(solve_cap)} seconds/run: 900 runs allocate "
                  f"{_n(900 * solve_cap / 3600, 2)} serial worker hours, or {_n(900 * solve_cap / 4 / 3600, 2)} at c4 / "
                  f"**{_n(900 * solve_cap / 8 / 3600, 2)} hours at c8**. "
                  f"For 600 runs, the corresponding c4/c8 figures are {_n(600 * solve_cap / 4 / 3600, 2)} / {_n(600 * solve_cap / 8 / 3600, 2)} hours. "
                  "These are allocated solve-time scenarios, before hidden evaluation, queueing, contention and reporting; "
                  "they are not measured completion times or guaranteed end-to-end upper bounds.", ""]

    preferred = forecasts[3]
    ready = screen_complete and calibration_complete and selected_complete and manifest is not None and len(main_tasks) == 100 and len(_families(main_tasks)) == 100 and not overlap and same_tasks
    if ready and preferred and available_main is not None:
        affordable_mean = Decimal(str(preferred["cost_mean"])) <= available_main
        safe_cap = (available_main / Decimal(900)).quantize(Decimal("0.0001"), rounding=ROUND_DOWN)
        time_sentence = (f"With {_n(hours_available, 1)} hours supplied as the remaining window, the ideal c4 mean-workload estimate "
                         f"{'fits' if preferred['serial_seconds_mean'] / 4 / 3600 <= hours_available else 'does not fit'}; "
                         "a tail/overhead allowance is still required."
                         if hours_available is not None else "Deadline fit remains unconfirmed until a remaining-time allowance is supplied (--hours-available).")
        lines += [("Prefer **100 families × 3 repetitions × 3 arms (900 runs)** conditionally: the mean measured cost projection "
                   + ("fits" if affordable_mean else "does not fit") + f" the {_dollars(available_main)} proposed main allocation. "
                   f"To fund every planned run within that allocation, an identical enforced per-run model-charge cap must be no more than "
                   f"**{_dollars(safe_cap, 4)}** (round down). The proposed {_dollars(run_cap_usd)} cap implies a "
                   f"{_dollars(run_cap_usd * 900)} ceiling for 900 runs and "
                   + ("exceeds" if run_cap_usd * 900 > available_main else "fits") + " that main allocation. "
                   "If the solving cap changes, confirm it still permits the intended workflow before freezing the main protocol. "
                   + time_sentence + f" If the cost/time gates fail, use the 100 × 2 × 3 option (600 runs, {_dollars(r2_run_cap_usd * 600)} ceiling at {_dollars(r2_run_cap_usd)}/run) or a smaller prespecified study. "
                   "Do not adjust sample size in response to the observed treatment advantage."), ""]
    else:
        lines += ["The preferred **100 × 3 × 3** option remains **conditional/unavailable**: complete the screen and all calibration arms, resolve every planned outcome, "
                  "confirm 100 validated disjoint main families, and reconcile spend before selecting repetitions or promising cost/time. "
                  "The 100 × 2 × 3 row is the lower-workload alternative; neither row authorizes an unbudgeted launch.", ""]

    if accounting["available"] and (accounting["upper"] > 0 or accounting["pending"] > 0):
        lines += ["Ledger caveat: unsettled/pending/usage-upper-bound entries remain conservatively charged until reconciled; do not describe the accounted total as exact final billing.", ""]
    lines += ["A main result must average repetitions within task and compare arms with paired, stratified family-cluster uncertainty; "
              "900 runs still represent 100 independent source families. The development sample cannot support a precise causal claim. "
              "Public Codeforces tasks may have appeared in training, and reference preflight does not eliminate oracle or benchmark contamination. "
              "These Python/CrossHair results do not establish an effect for Kotlin/Jormungandr.", "",
              f"Sources: `{screen_directory}/analysis.json`, `{screen_directory}/expected.json`, `{paired_directory}/analysis.json`, "
              f"`{paired_directory}/expected.json`, `{guided_directory}/analysis.json`, `{guided_directory}/expected.json`, "
              "optional `three-arm-analysis-v3.json`, `validated-task-manifest.json`, `source-quality.json`/`source-quality.md`, "
              f"{('`' + process_audit_source + '`, ') if process_audit_source else ''}and `spend/ledger.json` under the supplied run root.", ""]
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("runs/calibration-20261123"))
    parser.add_argument("--screen-directory", type=Path, default=Path("model-screen-v3"),
                        help="Replacement screen directory, relative to --root or absolute")
    parser.add_argument("--paired-directory", type=Path, default=Path("paired-calibration-v3"),
                        help="Replacement paired-calibration directory, relative to --root or absolute")
    parser.add_argument("--guided-directory", type=Path, default=Path("guided-calibration-v3"))
    parser.add_argument("--three-arm-analysis", type=Path, default=Path("three-arm-analysis-v3.json"),
                        help="Combined calibration analysis, relative to --root or absolute; optional when split analyses are available")
    parser.add_argument("--source-quality", type=Path, default=Path("source-quality.json"))
    parser.add_argument("--process-audit", type=Path, help="Host process audit; only matching v3 calibration rows are used")
    parser.add_argument("--cap-replay", type=Path, help="Recorded request-frontier replay; final file preferred over partial snapshot")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--model")
    parser.add_argument("--main-budget-usd", type=Decimal, default=Decimal("115"))
    parser.add_argument("--total-budget-usd", type=Decimal, default=Decimal("150"))
    parser.add_argument("--run-cap-usd", type=Decimal, default=Decimal("0.12"), help="Proposed per-run cap for the 900-run option")
    parser.add_argument("--r2-run-cap-usd", type=Decimal, default=Decimal("0.19"), help="Proposed per-run cap for the 600-run option")
    parser.add_argument("--reserve-usd", type=Decimal, default=Decimal("15"))
    parser.add_argument("--buffer-usd", type=Decimal, default=Decimal("5"))
    parser.add_argument("--hours-available", type=float)
    args = parser.parse_args(argv)
    try:
        for field in ("main_budget_usd", "total_budget_usd", "run_cap_usd", "r2_run_cap_usd", "reserve_usd", "buffer_usd"):
            value = getattr(args, field)
            if not value.is_finite() or value < 0:
                raise ValueError(f"{field} must be finite and nonnegative")
        if args.hours_available is not None and (not math.isfinite(args.hours_available) or args.hours_available < 0):
            raise ValueError("hours_available must be finite and nonnegative")
        audit_paths = ([args.root / args.process_audit] if args.process_audit is not None else
                       [args.root / name for name in ("process-audit-in-progress.json", "process-audit-v3.partial.json", "process-audit.json", "process-audit-v3.json")
                        if (args.root / name).exists()] +
                       [args.root / directory / "process-audit.json" for directory in (args.paired_directory, args.guided_directory)
                        if (args.root / directory / "process-audit.json").exists()])
        audited_runs = {}
        for path in audit_paths:
            for row in (_read(path) or {}).get("runs", []):
                identity = tuple(row.get(field) for field in ("batch", "model", "task_id", "condition", "repetition"))
                audited_runs[identity] = row
        replay_path = args.root / args.cap_replay if args.cap_replay is not None else next(
            (args.root / name for name in ("cap-replay.json", "cap-replay.partial.json") if (args.root / name).exists()), None)
        rendered = build_report(
            _read(args.root / args.screen_directory / "analysis.json"),
            _read(args.root / args.paired_directory / "analysis.json"),
            _read(args.root / "validated-task-manifest.json"),
            _read(args.root / "spend/ledger.json"),
            screen_expected=_read(args.root / args.screen_directory / "expected.json"),
            calibration_expected=_read(args.root / args.paired_directory / "expected.json"), model=args.model,
            guided=_read(args.root / args.guided_directory / "analysis.json"),
            guided_expected=_read(args.root / args.guided_directory / "expected.json"),
            three_arm_summary=_read(args.root / args.three_arm_analysis),
            screen_directory=args.screen_directory.as_posix(), paired_directory=args.paired_directory.as_posix(),
            guided_directory=args.guided_directory.as_posix(),
            source_quality=_read(args.root / args.source_quality),
            source_quality_md_available=(args.root / "source-quality.md").exists(),
            process_audit={"runs": list(audited_runs.values())} if audit_paths else None,
            process_audit_source=", ".join(path.as_posix() for path in audit_paths) if audit_paths else None,
            domain_audit=_read(args.root / args.guided_directory / "counterexample-domain-audit.json"),
            trace_notes_available=(args.root / args.guided_directory / "TRACE_NOTES.md").exists(),
            cap_replay=_read(replay_path) if replay_path else None,
            cap_replay_source=replay_path.name if replay_path else None,
            main_budget_usd=args.main_budget_usd, total_budget_usd=args.total_budget_usd,
            run_cap_usd=args.run_cap_usd, r2_run_cap_usd=args.r2_run_cap_usd, reserve_usd=args.reserve_usd, buffer_usd=args.buffer_usd,
            hours_available=args.hours_available)
    except (OSError, ValueError, KeyError, TypeError, InvalidOperation) as error:
        parser.error(str(error))
    output = args.output or args.root / "CALIBRATION_REPORT.md"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(rendered, encoding="utf-8")
    print(output.resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
