"""Bounded pinned-Parquet range reads to audit packaged source test preservation.

This diagnostic never runs a solution or alters an experiment manifest. It reads
only source names and test-suite columns, not source solutions. Optional installed
dependencies: requests and pyarrow. No downloads or installations are performed
other than the explicitly bounded HTTP byte ranges.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path
import re

import pyarrow.parquet as pq
import requests


class RangeFile(io.RawIOBase):
    def __init__(self, url: str, size: int, budget: int):
        super().__init__()
        self.url, self.size, self.budget = url, size, budget
        self.position = self.transferred = 0
        self.requests: list[dict] = []
        self.cache: dict[tuple[int, int], bytes] = {}

    def readable(self):
        return True

    def seekable(self):
        return True

    def tell(self):
        return self.position

    def seek(self, offset, whence=io.SEEK_SET):
        self.position = offset if whence == io.SEEK_SET else self.position + offset if whence == io.SEEK_CUR else self.size + offset
        if self.position < 0:
            raise ValueError("Negative seek")
        return self.position

    def read(self, length=-1):
        if length < 0:
            raise ValueError("Unbounded read forbidden")
        length = max(0, min(length, self.size - self.position))
        if not length:
            return b""
        key = self.position, length
        if key not in self.cache:
            if self.transferred + length > self.budget:
                raise ValueError(f"HTTP range budget exceeded: requested {length} after {self.transferred}, limit {self.budget}")
            start, end = self.position, self.position + length - 1
            # Distinct resolver URLs prevent intermediary caches from confusing ranges.
            url = self.url + f"?download=true&plinse_range={start}-{end}"
            with requests.get(url, headers={"Range": f"bytes={start}-{end}"}, timeout=30, stream=True) as response:
                response.raise_for_status()
                content_range = response.headers.get("Content-Range", "")
                match = re.fullmatch(r"bytes (\d+)-(\d+)/(\d+)", content_range)
                if response.status_code != 206 or not match or tuple(map(int, match.groups())) != (start, end, self.size):
                    raise ValueError(f"Server did not honor exact bounded range: {response.status_code}, {content_range}")
                data = response.raw.read(length + 1)
                if len(data) != length:
                    raise ValueError(f"Unexpected range response length {len(data)} != {length}")
                self.requests.append({"start": start, "end": end, "bytes": len(data), "content_range": content_range,
                                      "etag": response.headers.get("ETag")})
            self.transferred += len(data)
            self.cache[key] = data
        data = self.cache[key]
        self.position += len(data)
        return data


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def suite_stats(suite):
    values = suite["input"]
    return {"cases": len(values), "max_input_chars": max(map(len, values), default=0),
            "total_input_chars": sum(map(len, values)), "max_output_chars": max(map(len, suite["output"]), default=0),
            "semantic_json_sha256": digest(suite)}


def audit(project: Path, task_id: str, output: Path, budget: int, suites: list[str]):
    task = project / "benchmark-data/codecontests/tasks" / task_id
    metadata = load(task / "evaluator/source-metadata.json")
    source = load(project / "benchmark-data/codecontests/provenance/source.json")
    snapshot = load(project / "benchmark-data/codecontests/provenance/source-snapshot.json")
    file = next(item for item in snapshot["files"] if item["path"] == metadata["source_file"])
    url = f"https://huggingface.co/datasets/{source['dataset']}/resolve/{source['revision']}/{metadata['source_file']}"
    reader = RangeFile(url, file["size"], budget)
    parquet = pq.ParquetFile(reader, pre_buffer=False)
    remaining = metadata["source_row"]
    group = 0
    while remaining >= parquet.metadata.row_group(group).num_rows:
        remaining -= parquet.metadata.row_group(group).num_rows
        group += 1
    prefixes = ("name", *suites)
    relevant_columns = []
    rg = parquet.metadata.row_group(group)
    for index in range(rg.num_columns):
        column = rg.column(index)
        if column.path_in_schema.split(".")[0] in prefixes:
            relevant_columns.append({"column": column.path_in_schema, "compressed_bytes": column.total_compressed_size,
                                     "uncompressed_bytes": column.total_uncompressed_size})
    output.mkdir(parents=True, exist_ok=True)
    (output / (task_id + "-parquet-metadata.json")).write_text(json.dumps({
        "revision": source["revision"], "source_file": metadata["source_file"], "source_file_bytes": file["size"],
        "row_group": group, "group_rows": rg.num_rows, "row_groups": parquet.num_row_groups,
        "requested_suite_columns": relevant_columns}, indent=2) + "\n", encoding="utf-8")
    row = parquet.read_row_group(group, columns=list(prefixes), use_threads=False).slice(remaining, 1).to_pylist()[0]
    if row["name"] != metadata["name"]:
        raise ValueError(f"Wrong pinned source row: {row['name']} != {metadata['name']}")
    comparisons = {}
    for upstream, local in (("public_tests", "public/public-tests.json"), ("private_tests", "evaluator/private-tests.json"), ("generated_tests", "evaluator/generated-tests.json")):
        if upstream not in suites:
            continue
        bundled = load(task / local)
        comparisons[upstream] = {"identical": row[upstream] == bundled, "upstream": suite_stats(row[upstream]), "bundle": suite_stats(bundled)}
    result = {"task_id": task_id, "name": row["name"], "revision": source["revision"], "source_file": metadata["source_file"],
              "source_row": metadata["source_row"], "source_file_bytes": file["size"], "source_lfs_sha256": file["lfs"]["oid"],
              "range_bytes_transferred": reader.transferred, "range_budget_bytes": budget, "row_group": group,
              "row_within_group": remaining, "row_groups": parquet.num_row_groups, "suite_columns": relevant_columns,
              "comparisons": comparisons, "http_ranges": reader.requests,
              "integrity_limit": "Pinned HTTPS byte ranges and task-name match; full LFS file digest cannot be recomputed without downloading the full file."}
    output.mkdir(parents=True, exist_ok=True)
    (output / (task_id + "-pinned-source-tests.json")).write_text(json.dumps(row, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (output / (task_id + "-comparison.json")).write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("task_id", nargs="+", default=[])
    parser.add_argument("--project", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path, default=Path("runs/calibration-20261123/private-suite-audit"))
    parser.add_argument("--max-bytes-per-file", type=int, default=8 * 1024 * 1024)
    parser.add_argument("--suites", nargs="+", choices=("public_tests", "private_tests", "generated_tests"), default=["public_tests", "private_tests", "generated_tests"])
    args = parser.parse_args()
    for task_id in args.task_id:
        try:
            result = audit(args.project, task_id, args.output, args.max_bytes_per_file, args.suites)
            print(json.dumps({key: result[key] for key in ("task_id", "range_bytes_transferred", "source_file_bytes", "comparisons")}), flush=True)
        except Exception as error:
            print(json.dumps({"task_id": task_id, "error": f"{type(error).__name__}: {error}"}), flush=True)


if __name__ == "__main__":
    main()
