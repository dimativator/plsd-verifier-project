"""Check whether a smaller run cap would admit recorded request reservations."""
import argparse
from collections import defaultdict
from decimal import Decimal
import json
from pathlib import Path


def replay(root: Path, cap: Decimal) -> dict:
    # Run after controllers finish; atomic ledger writes preserve full JSON.
    ledger = json.loads((root / 'spend/ledger.json').read_text(encoding='utf-8'))
    completed = set()
    for batch in ['model-screen-v3', 'paired-calibration-v3', 'guided-calibration-v3']:
        for path in (root / batch).glob('*/*/*/*/result.json'):
            row = json.loads(path.read_text(encoding='utf-8'))
            if row['valid_run'] and not row['infrastructure_error']:
                completed.add('/'.join([batch] + [str(row[k]) for k in
                    ['phase', 'model', 'task_id', 'condition', 'repetition']]))
    groups = defaultdict(list)
    for row in ledger['reservations'].values():
        if row['run_id'] in completed:
            groups[row['run_id']].append(row)
    models = defaultdict(list)
    for identity, rows in groups.items():
        rows.sort(key=lambda row: row['created_unix'])
        maximum = Decimal(0)
        for index, row in enumerate(rows):
            before = sum((Decimal(previous['reserved'] if previous.get('finished_unix', float('inf'))
                > row['created_unix'] else previous['charged']) for previous in rows[:index]), Decimal(0))
            maximum = max(maximum, before + Decimal(row['reserved']))
        models[identity.split('/')[2]].append({'run_id': identity,
            'max_accounted_plus_next_reservation_usd': str(maximum)})
    return {'scope': 'Recorded original valid v3 attempts only. This is not a guarantee on unobserved main tasks.',
        'proposed_cap_usd': str(cap), 'models': {model: {
            'completed_runs': len(rows),
            'max_required_cap_usd': str(max(Decimal(r['max_accounted_plus_next_reservation_usd']) for r in rows)),
            'recorded_runs_fitting_proposed_cap': sum(Decimal(r['max_accounted_plus_next_reservation_usd']) <= cap for r in rows),
            'runs': rows} for model, rows in models.items()}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path('runs/calibration-20261123'))
    parser.add_argument('--cap', type=Decimal, default=Decimal('.12'))
    args = parser.parse_args()
    result = replay(args.root, args.cap)
    target = args.root / 'cap-replay.json'
    target.write_text(json.dumps(result, indent=2), encoding='utf-8')
    for model, row in result['models'].items():
        print(model, row['completed_runs'], 'max required', row['max_required_cap_usd'],
              'fit', row['recorded_runs_fitting_proposed_cap'])


if __name__ == '__main__':
    main()
