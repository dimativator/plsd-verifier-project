"""CPU-only checks of code extracted verbatim from the displayed guide."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

from experiments.runtime import VERIFIER_IMAGE, run_isolated

PROJECT = Path(__file__).resolve().parents[1]


def block_after(text: str, heading: str) -> str:
    remainder = text.split(heading + '\n', 1)[1]
    lines = remainder.splitlines()
    while lines and not lines[0].strip():
        lines.pop(0)
    selected = []
    for line in lines:
        if line.startswith('    '):
            selected.append(line[4:])
        elif not line.strip():
            selected.append('')
        else:
            break
    if not selected:
        raise ValueError('No indented guide block after: ' + heading)
    return '\n'.join(selected).rstrip() + '\n'


def save(path: Path, payload: object) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--guide', type=Path, default=PROJECT / 'experiments/CROSSHAIR_GUIDE.txt')
    parser.add_argument('--output', type=Path, default=PROJECT / 'runs/calibration-20261123/guidance-smoke/exact-guide-v1')
    args = parser.parse_args()
    guide, output = args.guide.resolve(), args.output.resolve()
    text = guide.read_text(encoding='utf-8')
    main_code = block_after(text, 'Example main.py (the real implementation being checked):')
    sidecar = block_after(text, 'Example check_contract.py (an agent-authored local check):')
    mutant = block_after(text, 'Now suppose the actual helper accidentally uses upper - 1:')
    replay = block_after(text, 'Replay that exact case in ordinary Python against the actual helper:')
    for source in (main_code, sidecar, mutant):
        ast.parse(source)
    if not replay.startswith("python - <<'PY'\n") or not replay.endswith('\nPY\n'):
        raise ValueError('Replay block is not the expected complete Python heredoc')
    ast.parse(replay.split('\n', 1)[1].rsplit('\nPY\n', 1)[0])
    tree = ast.parse(sidecar)
    functions = [node for node in tree.body if isinstance(node, ast.FunctionDef)]
    linked = (len(functions) == 1 and isinstance(functions[0].body[-1], ast.Return)
              and isinstance(functions[0].body[-1].value, ast.Call)
              and isinstance(functions[0].body[-1].value.func, ast.Name)
              and functions[0].body[-1].value.func.id == 'clamp'
              and any(isinstance(node, ast.ImportFrom) and node.module == 'main'
                      and any(item.name == 'clamp' for item in node.names) for node in tree.body))
    if not linked:
        raise ValueError('Displayed sidecar is not importing/calling the actual main.clamp')
    output.mkdir(parents=True, exist_ok=False)
    shutil.copyfile(guide, output / 'CROSSHAIR_GUIDE.exact.txt')
    for name, actual in (('correct', main_code), ('mutant', mutant), ('fixed', main_code)):
        workspace = output / name
        workspace.mkdir()
        (workspace / 'main.py').write_text(actual, encoding='utf-8')
        (workspace / 'check_contract.py').write_text(sidecar, encoding='utf-8')
        (workspace / 'replay.sh').write_text(replay, encoding='utf-8')
    assertion_source = '''def mistaken_property(x: int) -> int:
    assert x >= 0
    assert x == 0
    return x


def checked_property(x: int) -> int:
    assert x >= 0
    result = x
    assert result == 0
    return result
'''
    (output / 'correct' / 'assert_examples.py').write_text(assertion_source, encoding='utf-8')
    guide_sha = hashlib.sha256(guide.read_bytes()).hexdigest()
    image_id = subprocess.check_output(['docker', 'image', 'inspect', '--format', '{{.Id}}', VERIFIER_IMAGE], text=True).strip()
    save(output / 'source-bundle.json', {
        'guide_sha256': guide_sha, 'guide': str(guide), 'image_id': image_id,
        'extraction': 'Displayed four-space-indented blocks, with exactly four display spaces removed; no prior source constants reused.',
        'syntactic_python_blocks_valid': True, 'sidecar_imports_actual_implementation': linked,
        'extracted_source_sha256': {str(path.relative_to(output)): hashlib.sha256(path.read_bytes()).hexdigest()
                                    for path in output.glob('*/*') if path.is_file()},
        'model_api_calls': 0, 'benchmark_tasks_modified': False,
    })
    started = time.monotonic()
    commands = [('image_guide_hash', 'correct', 'python -c "import hashlib;from pathlib import Path;print(hashlib.sha256(Path(\'/opt/plinse/CROSSHAIR_GUIDE.txt\').read_bytes()).hexdigest())"'),
                ('unannotated', 'correct', 'verify main.py'),
                ('correct_verify', 'correct', 'verify check_contract.py'),
                ('correct_replay', 'correct', replay),
                ('mutant_verify', 'mutant', 'verify check_contract.py'),
                ('mutant_replay', 'mutant', replay),
                ('fixed_replay', 'fixed', replay),
                ('fixed_verify', 'fixed', 'verify check_contract.py'),
                ('assertion_semantics', 'correct', 'verify assert_examples.py')]
    results = {}
    for name, workspace, command in commands:
        result = run_isolated(output / workspace, command, image=VERIFIER_IMAGE, timeout=35)
        results[name] = {'command': command, **result}
        save(output / (name + '.json'), results[name])
        print(json.dumps({'check': name, 'returncode': result['returncode'], 'elapsed_seconds': result['elapsed_seconds'],
                          'stdout': result['stdout'], 'stderr': result['stderr']}), flush=True)
    diagnostic = lambda key: results[key]['stdout'] + '\n' + results[key]['stderr']
    checks = {
        'displayed_python_snippets_parse': True,
        'sidecar_imports_and_calls_actual_function': linked,
        'rebuilt_image_contains_exact_guide': results['image_guide_hash']['stdout'].strip() == guide_sha,
        'unannotated_function_reports_no_entrypoints': 'no checkable functions' in diagnostic('unannotated'),
        'correct_implementation_confirms_both_conditions': results['correct_verify']['returncode'] == 0 and diagnostic('correct_verify').count('Confirmed over all paths.') == 2,
        'exact_replay_passes_correct_implementation': results['correct_replay']['returncode'] == 0 and "'actual': 1, 'expected': 1" in results['correct_replay']['stdout'],
        'same_sidecar_finds_actual_mutant': results['mutant_verify']['returncode'] == 1 and 'false when calling check_clamp(' in diagnostic('mutant_verify'),
        'exact_replay_reproduces_legal_mutant_failure': results['mutant_replay']['returncode'] != 0 and "'actual': 0, 'expected': 1" in results['mutant_replay']['stdout'] and 'AssertionError' in results['mutant_replay']['stderr'],
        'repaired_actual_function_passes_replay_and_both_conditions': results['fixed_replay']['returncode'] == 0 and results['fixed_verify']['returncode'] == 0 and diagnostic('fixed_verify').count('Confirmed over all paths.') == 2,
        'leading_functional_assertion_is_assumed': 'info: Confirmed over all paths.' in diagnostic('assertion_semantics') and 'when calling mistaken_property' not in diagnostic('assertion_semantics'),
        'assertion_after_actual_computation_is_checked': 'AssertionError:  when calling checked_property(' in diagnostic('assertion_semantics') or 'AssertionError: when calling checked_property(' in diagnostic('assertion_semantics'),
    }
    report = {'kind': 'Exact displayed generic guide qualification', 'guide_sha256': guide_sha, 'image_id': image_id,
              'checks': checks, 'all_checks_passed': all(checks.values()), 'results': results,
              'elapsed_seconds': time.monotonic() - started,
              'content_audit': ['No task-specific solver signature, domain or functional property is supplied to benchmark agents.',
                                'The worked example is synthetic; it checks the actual imported implementation and uses its complete legal integer domain.',
                                'The guide distinguishes specification/domain errors, unsupported operations, empty checks and actual legal-input defects.',
                                'The guide warns about modular helper assumptions, unchecked callers/parsing, vacuous/narrow conditions, and time/complexity limitations.',
                                'Assertion-mode guidance matches the installed parser and the checked synthetic assumption-trap demonstration.',
                                'The underscore-support statement was qualified independently in the prior synthetic smoke.'],
              'limitations': ['Synthetic known bugs establish tool/example operation, not improved agent success.',
                              'Confirmed conditions remain subject to the verifier model and assumptions; this is not an independent mathematical proof.',
                              'The displayed mutant case is replayed exactly; counterexample search order may differ on other versions.']}
    save(output / 'report.json', report)
    lines = ['# Exact guide qualification', '', f'Guide SHA-256: `{guide_sha}`.', f'Image: `{image_id}`.', '',
             'All Python examples and the replay command were extracted from the displayed guide, rather than copied from earlier probe constants.', '',
             '```json', json.dumps(checks, indent=2), '```', '']
    for name, result in results.items():
        lines += [f'## {name}', '', f'{result["elapsed_seconds"]:.3f}s; return code {result["returncode"]}.', '',
                  '```text', result['stdout'] + result['stderr'], '```', '']
    lines += ['## Content audit', '', *['- ' + item for item in report['content_audit']], '',
              '## Limits', '', *['- ' + item for item in report['limitations']]]
    (output / 'README.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(json.dumps({'output': str(output), 'all_checks_passed': report['all_checks_passed'],
                      'checks': checks, 'elapsed_seconds': report['elapsed_seconds']}), flush=True)
    raise SystemExit(0 if report['all_checks_passed'] else 1)


if __name__ == '__main__':
    main()
