Analysis contract and interpretation
====================================

Run from the repository root using Python 3.10+; no third-party packages are needed:

```text
python -m experiments.analysis --results runs/calibration --expected runs/calibration/planned.json --phase calibration --conditions baseline verifier --per-run-cap-usd 0.28 --workers 4 --output runs/calibration/analysis.json
python -m experiments.analysis --results runs/main --expected runs/main/planned.json --phase main --conditions baseline verifier --output runs/main/analysis.json
python -m unittest experiments.test_analysis -v
```

An input directory is searched recursively for `result.json` only, to avoid reading
manifests and summaries as new observations. Explicit JSON or JSONL files may
contain individual run objects, lists, or a `runs`/`results` list. A planned manifest
may be a list or an object containing `runs`, `planned_runs`, or `jobs`.
Pass the same two condition names used by the runner, for example
`--conditions baseline crosshair` when the treatment is named `crosshair`.

Python callers may use:

```python
from experiments.analysis import analyze

summary = analyze(
    final_results, planned_run_specs,
    phase="main", conditions=("baseline", "verifier"),
    bootstrap_draws=10_000, seed=20261123,
    workers=4, per_run_cap_usd=0.28,
)
```

Input records
-------------

Every resolved result must contain:

```json
{
  "phase": "calibration",
  "model": "actual-provider-model-id",
  "task_id": "cf-example-A",
  "family_id": "source-family-id",
  "rating_band": "2000-2399",
  "condition": "baseline",
  "repetition": 0,
  "hidden_passed": false,
  "valid_run": true,
  "infrastructure_error": null,
  "exit_status": "budget_exhausted",
  "model_cost_usd": 0.025,
  "solve_seconds": 12.0,
  "evaluation_seconds": 0.5,
  "tool_events": []
}
```

`phase` is optional, but when supplied it must match the requested analysis.
Costs and times must be finite nonnegative numbers. They describe the recorded
attempt; solve time and evaluation time must be disjoint for their sum to be
meaningful. `model_cost_usd` is measured billed usage, not a configured ceiling.
If the controller writes `cost_is_upper_bound=true` for an unsettled reservation,
the summary flags that amount as a conservative bound rather than exact billing.
Missing measurements warn and suppress affected workload projections without
invalidating a legitimate hidden-test outcome. No tool-event schema is assumed.

A planned spec needs `model`, `task_id`, `condition`, and integer `repetition`.
Include `family_id` and `rating_band` to check observed metadata against the freeze.
List **every planned run, including those not started**, before collection.

For a distributed run, also freeze `analysis_stratum` in every planned spec and
resolved record, for example `"analysis_stratum": "ours:2000-2399"`. The distributed
plan forms this as `worker_id:rating_band` and keeps each source family on one
worker for all conditions and repetitions. Analysis uses this field when present;
otherwise it retains the legacy `rating_band` strata. A provided value must be a
nonempty string. Planned and observed field presence/value must match. Within a
task or family, mixing missing and explicit assignments is rejected even when
their effective stratum strings happen to coincide.

The identity is `(model, task_id, condition, repetition)`. Supply one resolved final
record per identity. Earlier infrastructure attempts must remain in separate raw
logs, with their billed costs in the controller ledger; they are not independent
repetitions. Duplicate identities block analysis rather than selecting whichever
attempt passed. Total observed spend here covers supplied resolved records only,
so reconcile it with the ledger before reporting total project spend.

All ordinary agent outcomes are scored on the last saved implementation, including
budget exhaustion, missing/invalid source, and failed hidden tests. A budget exit
is **not** an infrastructure failure. Set `valid_run=true`, use a Boolean
`hidden_passed`, and leave `infrastructure_error=null` for these scored outcomes.
For compatibility, recognized budget/step/token/wall limit exits with a Boolean
score are included even if a legacy runner wrote `valid_run=false`; a warning
makes this correction explicit. Unknown invalid statuses are blocked for review.

An unresolved infrastructure failure, missing planned record, duplicate identity,
unexpected run, changed family metadata, or unbalanced arm/repetition set blocks
the main treatment estimate. Do not repair a denominator by dropping the run.
The CLI exits with status 2 when blockers exist, while writing its audit summary.
Condition success summaries from incomplete data remain explicitly provisional.

Repeated benchmark scores and variance
--------------------------------------

Each condition reports `repeated_benchmark_scores`. One repetition is a complete
benchmark round on exactly the same task set. For round r, its score is
`S_r = 100 * mean(task_passed_in_round_r)`. The report lists each `S_r`, their
mean, the sample variance in squared percentage points, and the sample standard
deviation in percentage points. Variance and SD use **ddof=1** across rounds,
not the variance of individual binary task outcomes. For example, round scores
25%, 50%, 75% have mean 50%, sample variance 625 pp² and sample SD 25 pp. Repeated
50% scores have observed sample SD zero even when half the tasks fail each time.

Read `scores_percent`, `mean_score_percent`, `sample_sd_percentage_points`, and
`sample_variance_percentage_points_squared`. With one complete round the mean
is available but SD/variance are null. Three rounds provide only two variance
degrees of freedom, so the resulting dispersion estimate is unstable; an
observed SD of zero does not establish that the agent is deterministic.
Five rounds provide four variance degrees of freedom, improving the dispersion
estimate while still leaving substantial uncertainty about its population value.

Comparable aggregate scores/SD require a known complete planned denominator,
identical task sets in every round, unique final identities, and scored outcomes
for every task. Missing/unstarted runs, infrastructure-invalid outcomes,
unbalanced rounds, or higher-level design/settings blockers suppress these
aggregates. Per-round counts and explicitly labelled provisional subset scores
remain diagnostic only. Budget exits still contribute their final source score;
they are not dropped. A prespecified unequal-repetition design can retain the
existing equal-task primary estimate while its complete-round SD is unavailable.

This SD/variance describes **observed variation between repeated full rounds
on the fixed benchmark**. It is not a standard error, confidence interval of the
mean, or between-family uncertainty. The existing family-cluster intervals
below address comparable task-family composition within rating strata and keep
all repetitions together. Report these two sources of information separately.

Main inference
--------------

Screens and calibration report descriptive success, costs and runtime. They do
not emit a main treatment estimate or its CI. Models are always summarized
separately. Do not merge development outcomes with a main dataset or choose the
main sample size from the observed treatment difference.

Each completed model/condition sample also receives an **exploratory per-arm
success CI**, using the same stratified family bootstrap and retaining all its
repetitions. Read this at
`models[model].conditions[condition].success_interval`; the flat alias
`task_averaged_success_ci95_percent` is convenient for tables. These development
intervals describe success on comparable development families, not a causal
verifier effect or performance on an untouched test set. In particular, the v3
screen's four families with two repetitions remain four independent families,
with only two per band. Small-sample warnings are attached; multiple
model-screen intervals are not simultaneous and do not adjust for choosing the
best-looking model. A selected model still needs the independent main study.
Missing planned outcomes suppress these CIs rather than reporting a completed
subset as if it were the entire sample. Constant all-pass/all-fail samples retain
the existing degenerate-bootstrap warning and suppress a zero-width CI.
An eligible one-task-per-family sample receives the separate conservative
fallback described below instead of suggesting certainty.

For each task and condition, average its repeated Boolean outcomes. Give tasks
equal weight, even if task repetition counts differ. The primary effect in
percentage points is `100 * mean(task_mean_verifier - task_mean_baseline)`.
Each task must have the same planned repetition IDs in both arms. Different
tasks may have different repetition counts if this was frozen in advance.

The 95% interval uses 10,000 seeded percentile-bootstrap draws by default. Within
each inference stratum (`analysis_stratum` when present, otherwise `rating_band`),
sample the original number of **families** with replacement.
Retain every task/variant, condition, and repetition belonging to each sampled
family. Compute task-averaged arm success and their paired difference in each
draw. Preserve each stratum's original task weight even if sampled families have
unequal sizes. Thus repeating the same task outcomes ten times cannot artificially
narrow the family CI. No family may span strata; freeze a family-level stratum
before evaluation if related versions have different ratings. A family must also
retain one consistent explicit inference-stratum assignment across its variants,
conditions and repetitions; paired runs cannot silently change host assignment.

With two execution hosts, use frozen host-by-rating strata. For example, assigning
60 of 100 tasks to one host and 40 to the other, balanced within each rating band,
gives four fixed task weights of 0.30, 0.30, 0.20 and 0.20. Every bootstrap draw
resamples families only within those four cells and retains those weights. The
point estimate remains the equal-task mean: hosts do **not** receive equal weight.
This applies to paired effects, descriptive per-arm intervals, sparsity checks
and the conservative Hoeffding fallback. Hosts are fixed blocks, not sampled
independent replicates: the intervals are conditional on this execution-host
allocation and do not estimate variability across possible hosts, accounts,
hardware or host assignments. Identical task/condition/repetition identities must
still be resolved once before merging, rather than duplicated across hosts.

Outputs expose `family_counts_by_analysis_stratum`,
`task_counts_by_analysis_stratum`, and `analysis_stratum_task_weights` for auditing
the inference cells. Existing `family_counts_by_rating_band` and
`task_counts_by_rating_band` continue to summarize the actual rating bands;
their keys are not repurposed as host labels. Results without `analysis_stratum`
retain their original rating-only numerical inference.

This interval addresses sampling comparable task families within the frozen
inference-stratum task weights, keeping their observed repeated runs together. It does not
separately estimate Monte Carlo uncertainty conditional on this exact fixed
benchmark. A fixed-benchmark interval would require a separately specified
within-task run model/resampling analysis and enough repetitions; two runs per
arm give little information about each task's solve probability.

Few families can give poor bootstrap coverage. Fewer than 20 families triggers a
warning. A stratum with fewer than two families cannot estimate its own
between-family variation, so bootstrap CIs are suppressed. Constant or percentile-degenerate
bootstrap bounds also produce `ci95=null`, `bootstrap_degenerate=true`, and retain
the raw bounds only for diagnostics. Never present those raw bounds as a precise
zero-width confidence interval or proof of equivalence. This also applies when
every observed solution passes or fails. Report the sample size, estimate, and
limitation instead. Nonzero-width intervals with very small samples remain
approximate; the warnings are not a guarantee of valid coverage above a threshold.

If the bootstrap CI is suppressed and **each family contains exactly one task**,
the output also provides a distribution-free, two-sided 95% Hoeffding interval.
Let `w_s` be a stratum's fixed task weight and `n_s` its independent family count.
For task-level success means in `[0,1]`, the half-width is
`sqrt(log(2/0.05)/2 * sum(w_s**2/n_s))`. For paired task effects in `[-1,1]`,
double that half-width. Bounds are converted to percent/percentage points and
clipped to `[0,100]` or `[-100,100]`. Repetitions stay inside each bounded family
observation and do not increase `n_s`. This requires independent families and
fixed stratum weights. No fallback is supplied for multiple tasks per family.

The fallback is deliberately conservative: six all-pass families, three per band,
give about **44.56–100%**; 100 families with identical zero paired effects give
about **−27.16 to +27.16 pp**. These bounds convey limited information, rather than
precision or evidence of equivalence. Screen intervals still do not adjust for
model selection or simultaneous comparisons.

The bootstrap fields remain unchanged: `ci95`/`ci95_percent` stays null and
`bootstrap_degenerate` remains true when applicable. Read the separate
`conservative_ci95` in a main arm/effect interval, or
`success_interval.conservative_ci95_percent` for descriptive success. The flat
condition alias is `task_averaged_success_conservative_ci95_percent`.
`ci_method="hoeffding_conservative_fallback"` identifies this case;
`ci_method="family_cluster_percentile_bootstrap"` identifies an ordinary
nondegenerate bootstrap CI. Label the chosen method alongside any reported
interval and retain the small-sample warnings.

Coverage and the shared-baseline three-arm study
------------------------------------------------

`analyze(..., confidence_level=.95, descriptive_confidence_level=.95)` separates
main contrast coverage from descriptive per-arm coverage. For example,
`--confidence-level .975` uses the 1.25th/98.75th bootstrap percentiles and the
matching alpha=.025 Hoeffding bound. General interval fields are
`confidence_level`, `confidence_interval`, and
`conservative_confidence_interval`; descriptive success uses
`confidence_interval_percent` and `conservative_confidence_interval_percent`.
Legacy `ci95`/`ci95_percent` fields and their conservative aliases are populated
**only** at confidence level .95. They are null at .975, to avoid mislabelling a
97.5% interval as 95%. Descriptive per-arm intervals stay at .95 by default.

For optional access and guided verification against a shared baseline, use:

```text
python -m experiments.three_arm_analysis --results runs/calibration-20261123/paired-calibration-v3 runs/calibration-20261123/guided-calibration-v3 --expected runs/calibration-20261123/paired-calibration-v3/expected.json runs/calibration-20261123/guided-calibration-v3/expected.json --phase calibration --output runs/calibration-20261123/three-arm-analysis-v3.json
python -m experiments.three_arm_analysis --results runs/main --expected runs/main/expected.json --phase main --output runs/main/three-arm-analysis.json
python -m unittest experiments.test_analysis experiments.test_three_arm_analysis experiments.test_calibration_report -v
```

The arms are `baseline`, `verifier` (optional access), and `guided_verifier`.
The prespecified co-primary contrasts are optional versus baseline and guided
versus baseline. Each gets a two-sided 97.5% interval by Bonferroni, for
approximately 95% familywise coverage with percentile-bootstrap intervals.
Bonferroni does not require the two shared-baseline contrasts to be independent;
its guarantee still depends on each underlying interval's marginal coverage.
The small-sample bootstrap limitations remain. Both pairs use the same seed and
family/stratum scheme. No main causal intervals are emitted for calibration;
it keeps per-arm descriptive intervals and paired point changes only.

When explicitly requested, `--exploratory-contrasts` additionally reports paired
development uncertainty under `exploratory_contrasts`, using the same .975
coverage and family-bootstrap/Hoeffding procedure for both calibration contrasts.
It calls the mathematical estimator directly without relabelling the data as
main. The ordinary calibration `paired_effect` stays suppressed. These intervals
are explicitly exploratory: development outcomes were already inspected, only
ten source families are available, and neither adjustment nor repetition makes
them confirmatory main evidence. The option is rejected for phase main and never
bypasses missing-outcome or balanced-design checks. The report generator displays
this optional section with its actual coverage and development warnings.

Multiple result/expected inputs merge distinct run identities. Planned task and
repetition sets must match across all three arms. Missing outcomes, duplicate
identities, incompatible effort/output/step/solve settings, or unknown arms block
the full three-arm main inference. Source/prompt hashes may differ legitimately
when adding the guided condition, so those hashes alone do not reject a merge.
The top-level `models` summary holds all three arms;
`contrast_analyses.optional_vs_baseline` and `.guided_vs_baseline` hold the pairs.
Top-level spending counts each supplied baseline run once. Do not sum the two
contrast-level spend totals, because they both include those same baseline rows.

Three-arm workload projections require all three measured calibration arms.
At 100 families and two, three, five or six repetitions, there are
**600, 900, 1,500 or 1,800 runs**. The current five-round study contains all 100
tasks and three conditions in every round. Repetitions 1–3 run here and 4–5 run
on the colleague's worker; analysis retains all five repetitions within each
source-family cluster and uses rating strata.
For illustration, enforced per-run ceilings of $.19 and $.12 respectively give
$114 and $108 maximum main model charges, before calibration/retries.
With a $115 main allocation, 900 runs require an identical cap no greater than
$115/900, rounded down (e.g. $.12). Lowering the solving cap can change outcomes;
confirm the workflow remains feasible before freezing the main protocol. These
are historical allocation examples. Five repetitions at $.12/run have a **$180**
sum of individual run ceilings. The current global main allocation is **$140**,
split **$84/$56** across the two workers. Admission is checked before each full
round, so the global cap can leave planned rounds unstarted. Such runs remain
missing and block complete-study aggregates; they are not scored as failures.
Preparation and replacements also count toward the combined $150 study ceiling.
Six repetitions would instead have a $216 sum of individual run ceilings.

`python -m experiments.calibration_report --root runs/calibration-20261123`
renders the report from replacement v3 summaries, their frozen configs, validated
manifest and shared ledger. It prefers `three-arm-analysis-v3.json` when present,
and otherwise combines separate optional/guided calibration summaries. Excluded
earlier unversioned/v2 debug batches never enter performance tables, but their
charges remain in the shared spend total. Process-audit rows are likewise filtered
to the selected v3 paired/guided batch names. The report includes
`source-quality.json`/`source-quality.md` limits: original source-private test
success does not establish full-domain correctness, full Codeforces judge
acceptance, or large-input efficiency. The report's c4/c8 time figures are ideal
workload divisions, not measured concurrency speedups. At a 600-second nominal
solve cap, 900 runs allocate 18.75 hours at c8 before evaluation/overhead; this
budget scenario is distinct from the measured mean-runtime forecast.

Workload projections
--------------------

For each model, the summary projects 100 families, one task per family, two arms,
and two, three, five or six repetitions: **400, 600, 1,000 or 1,200 main runs**. Both arms need
scored, measured calibration runs. Mean measured costs estimate expected main
spend; mean solve-plus-evaluation time estimates serial worker time. The nominal
elapsed time divides that workload by workers and assumes full utilization.
It excludes setup, contention, queueing and report writing and is not CPU time.
For distributed execution, project each host's assigned workload using its own
concurrency and observed throughput, then take the maximum host time. A fixed
60/40 task allocation is not generally equivalent to dividing the pooled work
by the sum of workers; the slower or more heavily loaded host determines finish
time. Keep host startup, transfer and report overhead separate.
Extrapolation assumes the calibration difficulty/rating mix, prompts and run
budgets represent the main study. A screen on easy problems or under different
caps cannot establish a reliable runtime/cost estimate for hard main tasks.

Per-run medians/p90/p95/minima/maxima are also scaled to show empirical scenarios.
The sum of per-run p95 values is **not the p95 of total spend/runtime**, a confidence
bound, or a guaranteed limit. Small calibration samples may miss tail behavior.
Scored runs with infrastructure problems resolved elsewhere do not estimate the
retry overhead; reserve that separately, together with calibration charges.

Only `--per-run-cap-usd` yields a deterministic model-charge ceiling, and only if
the controller actually enforces it. At $0.28 per run, the 400-run ceiling is
$112; the 600-run ceiling is $168, before calibration/retries, so that latter
option cannot fit a $150 total budget under that cap. The analysis tool does not
enforce spending. The controller must atomically reserve conservative maximum
charges for **all in-flight requests**, including retries, before dispatch.
